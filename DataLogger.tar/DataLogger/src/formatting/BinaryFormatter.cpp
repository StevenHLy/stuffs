/**
 * @file BinaryFormatter.cpp
 * @brief Implementation of binary trace formatter
 */

#include "BinaryFormatter.hpp"
#include <cstring>

namespace data_logger {

// Magic number: 'TRAC' in ASCII
static const std::uint32_t MAGIC_NUMBER = 0x54524143;
static const std::uint16_t VERSION_MAJOR = 1;
static const std::uint16_t VERSION_MINOR = 0;
static const std::size_t FILE_HEADER_SIZE = 32;
static const std::size_t ENTRY_HEADER_SIZE = 16;

BinaryFormatter::BinaryFormatter()
    : header_written_(false)
    , temp_buffer_() {
    temp_buffer_.reserve(1024); // Pre-allocate for efficiency
}

void BinaryFormatter::writeFileHeader(FileWriter& writer, std::uint64_t creation_time) {
    temp_buffer_.clear();
    temp_buffer_.reserve(FILE_HEADER_SIZE);
    
    // Magic (4 bytes)
    writeLittleEndian32(temp_buffer_, MAGIC_NUMBER);
    
    // Version Major (2 bytes)
    writeLittleEndian16(temp_buffer_, VERSION_MAJOR);
    
    // Version Minor (2 bytes)
    writeLittleEndian16(temp_buffer_, VERSION_MINOR);
    
    // Creation Timestamp (8 bytes)
    writeLittleEndian64(temp_buffer_, creation_time);
    
    // Entry Count (8 bytes) - 0 = unknown
    writeLittleEndian64(temp_buffer_, 0);
    
    // Reserved (8 bytes)
    writeLittleEndian64(temp_buffer_, 0);
    
    writer.write(temp_buffer_.data(), temp_buffer_.size());
    header_written_ = true;
}

void BinaryFormatter::writeEntry(FileWriter& writer, const TraceLogEntry& entry) {
    temp_buffer_.clear();
    temp_buffer_.reserve(ENTRY_HEADER_SIZE + entry.payload_size);
    
    // Timestamp (8 bytes)
    writeLittleEndian64(temp_buffer_, entry.timestamp_ns);
    
    // Message ID (4 bytes)
    writeLittleEndian32(temp_buffer_, entry.message_id);
    
    // Payload Size (4 bytes)
    writeLittleEndian32(temp_buffer_, entry.payload_size);
    
    // Write entry header
    writer.write(temp_buffer_.data(), temp_buffer_.size());
    
    // Write payload directly (no endianness conversion for raw data)
    if (entry.payload_size > 0 && entry.payload != nullptr) {
        writer.write(entry.payload, entry.payload_size);
    }
}

void BinaryFormatter::writeLittleEndian16(std::vector<char>& buffer, std::uint16_t value) {
    buffer.push_back(static_cast<char>(value & 0xFF));
    buffer.push_back(static_cast<char>((value >> 8) & 0xFF));
}

void BinaryFormatter::writeLittleEndian32(std::vector<char>& buffer, std::uint32_t value) {
    buffer.push_back(static_cast<char>(value & 0xFF));
    buffer.push_back(static_cast<char>((value >> 8) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 16) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 24) & 0xFF));
}

void BinaryFormatter::writeLittleEndian64(std::vector<char>& buffer, std::uint64_t value) {
    buffer.push_back(static_cast<char>(value & 0xFF));
    buffer.push_back(static_cast<char>((value >> 8) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 16) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 24) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 32) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 40) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 48) & 0xFF));
    buffer.push_back(static_cast<char>((value >> 56) & 0xFF));
}

} // namespace data_logger
