/**
 * @file BinaryFormatter.hpp
 * @brief Binary serialization for trace log entries
 */

#pragma once

#include "../include/DataLogger/LogEntry.hpp"
#include "writers/FileWriter.hpp"
#include <cstdint>
#include <vector>

namespace data_logger {

/**
 * @brief Formats trace log entries into binary format
 * 
 * Binary format specification:
 * 
 * File Header (32 bytes):
 *   - Magic (4 bytes): 0x54524143 ('TRAC')
 *   - Version Major (2 bytes): 1
 *   - Version Minor (2 bytes): 0
 *   - Creation Timestamp (8 bytes): nanoseconds since Unix epoch
 *   - Entry Count (8 bytes): 0 = unknown
 *   - Reserved (8 bytes): zero
 * 
 * Trace Entry (variable size):
 *   - Timestamp (8 bytes): nanoseconds since Unix epoch
 *   - Message ID (4 bytes): user-defined message type
 *   - Payload Size (4 bytes): bytes in payload
 *   - Payload (N bytes): binary data
 * 
 * All values in little-endian byte order.
 */
class BinaryFormatter {
public:
    BinaryFormatter();
    
    /**
     * @brief Write the file header (call once at file creation)
     * @param writer FileWriter to write to
     * @param creation_time Creation timestamp in nanoseconds since Unix epoch
     */
    void writeFileHeader(FileWriter& writer, std::uint64_t creation_time);
    
    /**
     * @brief Write a trace entry to the file
     * @param writer FileWriter to write to
     * @param entry The trace entry to serialize
     */
    void writeEntry(FileWriter& writer, const TraceLogEntry& entry);
    
private:
    /**
     * @brief Convert uint16_t to little-endian bytes
     */
    void writeLittleEndian16(std::vector<char>& buffer, std::uint16_t value);
    
    /**
     * @brief Convert uint32_t to little-endian bytes
     */
    void writeLittleEndian32(std::vector<char>& buffer, std::uint32_t value);
    
    /**
     * @brief Convert uint64_t to little-endian bytes
     */
    void writeLittleEndian64(std::vector<char>& buffer, std::uint64_t value);
    
    bool header_written_;
    std::vector<char> temp_buffer_;
};

} // namespace data_logger
