/**
 * @file TextFormatter.cpp
 * @brief Implementation of text log formatter
 */

#include "TextFormatter.hpp"
#include "../include/DataLogger/LogLevel.hpp"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace data_logger {

std::string TextFormatter::format(const TextLogEntry& entry) {
    std::ostringstream oss;
    oss << formatTimestamp(entry.timestamp_ns) << " "
        << formatLevel(entry.level) << " "
        << entry.message << "\n";
    return oss.str();
}

std::string TextFormatter::formatTimestamp(std::uint64_t timestamp_ns) {
    // Convert nanoseconds to seconds and nanosecond remainder
    std::uint64_t seconds = timestamp_ns / 1000000000ULL;
    std::uint64_t nanos = timestamp_ns % 1000000000ULL;
    
    // Convert to time_t for standard time formatting
    std::time_t time_seconds = static_cast<std::time_t>(seconds);
    std::tm* tm_info = std::gmtime(&time_seconds);
    
    if (tm_info == nullptr) {
        return "[INVALID_TIMESTAMP]";
    }
    
    // Format: [YYYY-MM-DD HH:MM:SS.nnnnnnnnn]
    std::ostringstream oss;
    oss << "[" 
        << std::setfill('0')
        << std::setw(4) << (tm_info->tm_year + 1900) << "-"
        << std::setw(2) << (tm_info->tm_mon + 1) << "-"
        << std::setw(2) << tm_info->tm_mday << " "
        << std::setw(2) << tm_info->tm_hour << ":"
        << std::setw(2) << tm_info->tm_min << ":"
        << std::setw(2) << tm_info->tm_sec << "."
        << std::setw(9) << nanos
        << "]";
    
    return oss.str();
}

std::string TextFormatter::formatLevel(LogLevel level) {
    std::ostringstream oss;
    oss << "[" << toString(level) << "]";
    return oss.str();
}

} // namespace data_logger
