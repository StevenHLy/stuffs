/**
 * @file TextFormatter.hpp
 * @brief Formatter for text log entries
 */

#pragma once

#include "../include/DataLogger/LogEntry.hpp"
#include <cstdint>
#include <string>

namespace data_logger {

/**
 * @brief Formats text log entries into human-readable strings
 * 
 * Format: [YYYY-MM-DD HH:MM:SS.nnnnnnnnn] [LEVEL] message\n
 * Example: [2026-07-23 14:32:45.123456789] [INFO] System initialized
 */
class TextFormatter {
public:
    /**
     * @brief Format a text log entry to a string
     * @param entry The log entry to format
     * @return Formatted string with newline
     */
    std::string format(const TextLogEntry& entry);
    
private:
    /**
     * @brief Format a timestamp to ISO 8601 format with nanoseconds
     * @param timestamp_ns Timestamp in nanoseconds since Unix epoch
     * @return Formatted timestamp string [YYYY-MM-DD HH:MM:SS.nnnnnnnnn]
     */
    std::string formatTimestamp(std::uint64_t timestamp_ns);
    
    /**
     * @brief Format a log level to string with brackets
     * @param level The log level
     * @return Formatted level string [LEVEL]
     */
    std::string formatLevel(LogLevel level);
};

} // namespace data_logger
