/**
 * @file FileWriter.hpp
 * @brief Buffered file I/O for log files
 */

#pragma once

#include <cstddef>
#include <fstream>
#include <string>
#include <vector>

namespace data_logger {

/**
 * @brief Buffered file writer for efficient log file I/O
 * 
 * Manages file handle lifecycle and buffers writes in memory to reduce
 * system calls. Flushes automatically when buffer is full or on demand.
 */
class FileWriter {
public:
    /**
     * @brief Construct a FileWriter with specified buffer size
     * @param filePath Path to the file to write
     * @param bufferSize Size of the write buffer in bytes
     * @throws std::runtime_error if file cannot be opened
     */
    explicit FileWriter(const std::string& filePath, std::size_t bufferSize = 65536);
    
    /**
     * @brief Destructor - flushes and closes file
     */
    ~FileWriter();
    
    // Non-copyable, non-movable for simplicity
    FileWriter(const FileWriter&) = delete;
    FileWriter& operator=(const FileWriter&) = delete;
    
    /**
     * @brief Write data to the buffer (and file if buffer is full)
     * @param data Pointer to data to write
     * @param size Number of bytes to write
     * @throws std::runtime_error if write fails
     */
    void write(const void* data, std::size_t size);
    
    /**
     * @brief Flush buffer contents to disk
     * @throws std::runtime_error if flush fails
     */
    void flush();
    
    /**
     * @brief Close the file (also flushes)
     * @throws std::runtime_error if close fails
     */
    void close();
    
    /**
     * @brief Check if the file is open
     * @return True if file is open and writable
     */
    bool isOpen() const;
    
private:
    /**
     * @brief Internal flush implementation
     */
    void flushBuffer();
    
    std::ofstream file_;
    std::vector<char> buffer_;
    std::size_t buffer_size_;
    std::size_t buffer_used_;
    std::string file_path_;
};

} // namespace data_logger
