/**
 * @file FileWriter.cpp
 * @brief Implementation of buffered file writer
 */

#include "FileWriter.hpp"
#include <cstring>
#include <stdexcept>

namespace data_logger {

FileWriter::FileWriter(const std::string& filePath, std::size_t bufferSize)
    : file_()
    , buffer_(bufferSize)
    , buffer_size_(bufferSize)
    , buffer_used_(0)
    , file_path_(filePath) {
    
    // Open file in binary mode, create if doesn't exist, append if exists
    file_.open(filePath, std::ios::binary | std::ios::app);
    
    if (!file_.is_open()) {
        throw std::runtime_error("Failed to open file for writing: " + filePath);
    }
    
    if (!file_.good()) {
        throw std::runtime_error("File opened but in bad state: " + filePath);
    }
}

FileWriter::~FileWriter() {
    try {
        if (isOpen()) {
            flush();
            close();
        }
    } catch (...) {
        // Suppress exceptions in destructor
    }
}

void FileWriter::write(const void* data, std::size_t size) {
    if (!isOpen()) {
        throw std::runtime_error("Cannot write to closed file: " + file_path_);
    }
    
    const char* byteData = static_cast<const char*>(data);
    std::size_t remaining = size;
    
    while (remaining > 0) {
        std::size_t available = buffer_size_ - buffer_used_;
        
        if (available == 0) {
            // Buffer is full, flush it
            flushBuffer();
            available = buffer_size_;
        }
        
        // Copy as much as we can to the buffer
        std::size_t toCopy = (remaining < available) ? remaining : available;
        std::memcpy(buffer_.data() + buffer_used_, byteData, toCopy);
        buffer_used_ += toCopy;
        byteData += toCopy;
        remaining -= toCopy;
    }
}

void FileWriter::flush() {
    if (buffer_used_ > 0) {
        flushBuffer();
    }
    
    if (file_.is_open()) {
        file_.flush();
        if (!file_.good()) {
            throw std::runtime_error("Failed to flush file: " + file_path_);
        }
    }
}

void FileWriter::close() {
    if (isOpen()) {
        flush();
        file_.close();
        
        if (file_.fail()) {
            throw std::runtime_error("Failed to close file: " + file_path_);
        }
    }
}

bool FileWriter::isOpen() const {
    return file_.is_open() && file_.good();
}

void FileWriter::flushBuffer() {
    if (buffer_used_ > 0 && file_.is_open()) {
        file_.write(buffer_.data(), buffer_used_);
        
        if (!file_.good()) {
            throw std::runtime_error("Failed to write to file: " + file_path_);
        }
        
        buffer_used_ = 0;
    }
}

} // namespace data_logger
