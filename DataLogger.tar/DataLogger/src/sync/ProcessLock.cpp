/**
 * @file ProcessLock.cpp
 * @brief Implementation of file-based process lock
 */

#include "ProcessLock.hpp"
#include <cerrno>
#include <cstring>
#include <fcntl.h>
#include <stdexcept>
#include <system_error>
#include <unistd.h>

namespace data_logger {

ProcessLock::ProcessLock(const std::string& lockFilePath)
    : fd_(-1)
    , lock_file_path_(lockFilePath)
    , locked_(false) {
    
    // Create or open the lock file
    fd_ = open(lock_file_path_.c_str(), O_RDWR | O_CREAT, 0666);
    
    if (fd_ == -1) {
        throw std::runtime_error("Failed to create/open lock file '" + lock_file_path_ + "': " +
                                 std::strerror(errno));
    }
}

ProcessLock::~ProcessLock() {
    if (fd_ != -1) {
        // Unlock if still locked (will be released automatically anyway)
        if (locked_) {
            try {
                unlock();
            } catch (...) {
                // Suppress exceptions in destructor
            }
        }
        close(fd_);
    }
}

void ProcessLock::lock() {
    if (fd_ == -1) {
        throw std::runtime_error("Cannot lock with invalid file descriptor");
    }
    
    struct flock fl;
    fl.l_type = F_WRLCK;    // Write lock (exclusive)
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;           // Lock entire file
    
    // F_SETLKW: blocking lock - wait until we can acquire it
    if (fcntl(fd_, F_SETLKW, &fl) == -1) {
        throw std::system_error(errno, std::system_category(),
                                "Failed to acquire file lock on '" + lock_file_path_ + "'");
    }
    
    locked_ = true;
}

void ProcessLock::unlock() {
    if (fd_ == -1) {
        throw std::runtime_error("Cannot unlock with invalid file descriptor");
    }
    
    if (!locked_) {
        return; // Already unlocked
    }
    
    struct flock fl;
    fl.l_type = F_UNLCK;    // Unlock
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;
    
    if (fcntl(fd_, F_SETLK, &fl) == -1) {
        throw std::system_error(errno, std::system_category(),
                                "Failed to release file lock on '" + lock_file_path_ + "'");
    }
    
    locked_ = false;
}

bool ProcessLock::tryLock() {
    if (fd_ == -1) {
        return false;
    }
    
    struct flock fl;
    fl.l_type = F_WRLCK;
    fl.l_whence = SEEK_SET;
    fl.l_start = 0;
    fl.l_len = 0;
    
    // F_SETLK: non-blocking lock
    if (fcntl(fd_, F_SETLK, &fl) == -1) {
        return false; // Lock not available
    }
    
    locked_ = true;
    return true;
}

} // namespace data_logger
