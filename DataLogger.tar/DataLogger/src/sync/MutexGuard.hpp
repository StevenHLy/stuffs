/**
 * @file MutexGuard.hpp
 * @brief Thread synchronization wrapper
 */

#pragma once

#include <mutex>

namespace data_logger {

/**
 * @brief Simple wrapper around std::mutex for consistent interface
 */
class MutexGuard {
public:
    MutexGuard() = default;
    ~MutexGuard() = default;
    
    // Non-copyable, non-movable
    MutexGuard(const MutexGuard&) = delete;
    MutexGuard& operator=(const MutexGuard&) = delete;
    
    void lock() {
        mutex_.lock();
    }
    
    void unlock() {
        mutex_.unlock();
    }
    
    bool tryLock() {
        return mutex_.try_lock();
    }
    
private:
    std::mutex mutex_;
};

/**
 * @brief RAII lock guard for MutexGuard
 */
class ScopedLock {
public:
    explicit ScopedLock(MutexGuard& guard)
        : guard_(guard)
        , locked_(true) {
        guard_.lock();
    }
    
    ~ScopedLock() {
        if (locked_) {
            guard_.unlock();
        }
    }
    
    // Non-copyable, non-movable
    ScopedLock(const ScopedLock&) = delete;
    ScopedLock& operator=(const ScopedLock&) = delete;
    
private:
    MutexGuard& guard_;
    bool locked_;
};

} // namespace data_logger
