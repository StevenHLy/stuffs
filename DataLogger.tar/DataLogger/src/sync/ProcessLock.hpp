/**
 * @file ProcessLock.hpp
 * @brief Inter-process synchronization using file-based locking
 */

#pragma once

#include <string>

namespace data_logger {

/**
 * @brief File-based lock for inter-process synchronization
 * 
 * Uses fcntl file locking (F_SETLKW) to provide mutual exclusion across
 * multiple processes writing to the same log file. This implementation
 * works over NFS and automatically releases locks when the process exits.
 */
class ProcessLock {
public:
    /**
     * @brief Create or open a lock file
     * @param lockFilePath Path to the lock file (will be created if it doesn't exist)
     * @throws std::runtime_error if lock file cannot be created/opened
     */
    explicit ProcessLock(const std::string& lockFilePath);
    
    /**
     * @brief Destructor - closes lock file (lock is automatically released)
     */
    ~ProcessLock();
    
    // Non-copyable, non-movable
    ProcessLock(const ProcessLock&) = delete;
    ProcessLock& operator=(const ProcessLock&) = delete;
    
    /**
     * @brief Acquire the lock (blocking)
     * @throws std::runtime_error if lock acquisition fails
     */
    void lock();
    
    /**
     * @brief Release the lock
     * @throws std::runtime_error if unlock fails
     */
    void unlock();
    
    /**
     * @brief Try to acquire the lock without blocking
     * @return True if lock was acquired, false otherwise
     */
    bool tryLock();
    
private:
    int fd_;
    std::string lock_file_path_;
    bool locked_;
};

/**
 * @brief RAII lock guard for ProcessLock
 */
class ProcessLockGuard {
public:
    explicit ProcessLockGuard(ProcessLock& lock)
        : lock_(lock)
        , locked_(true) {
        lock_.lock();
    }
    
    ~ProcessLockGuard() {
        if (locked_) {
            lock_.unlock();
        }
    }
    
    // Non-copyable, non-movable
    ProcessLockGuard(const ProcessLockGuard&) = delete;
    ProcessLockGuard& operator=(const ProcessLockGuard&) = delete;
    
private:
    ProcessLock& lock_;
    bool locked_;
};

} // namespace data_logger
