/**
 * @file LogEntry.cpp
 * @brief Implementation of log entry structures
 */

#include "../include/DataLogger/LogEntry.hpp"
#include <chrono>

namespace data_logger {

namespace {
    /**
     * @brief Get current timestamp in nanoseconds since Unix epoch
     * @return Timestamp in nanoseconds
     */
    std::uint64_t getCurrentTimestamp() {
        auto now = std::chrono::system_clock::now();
        auto duration = now.time_since_epoch();
        return std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
    }
} // anonymous namespace

// TextLogEntry implementations
TextLogEntry::TextLogEntry(LogLevel lvl, const std::string& msg)
    : timestamp_ns(getCurrentTimestamp())
    , level(lvl)
    , message(msg) {
}

TextLogEntry::TextLogEntry(std::uint64_t ts, LogLevel lvl, const std::string& msg)
    : timestamp_ns(ts)
    , level(lvl)
    , message(msg) {
}

// TraceLogEntry implementations
TraceLogEntry::TraceLogEntry(std::uint32_t id, const void* data, std::size_t size)
    : timestamp_ns(getCurrentTimestamp())
    , message_id(id)
    , payload_size(static_cast<std::uint32_t>(size))
    , payload(data) {
}

TraceLogEntry::TraceLogEntry(std::uint64_t ts, std::uint32_t id, const void* data, std::size_t size)
    : timestamp_ns(ts)
    , message_id(id)
    , payload_size(static_cast<std::uint32_t>(size))
    , payload(data) {
}

} // namespace data_logger
