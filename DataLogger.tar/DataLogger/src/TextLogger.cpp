/**
 * @file TextLogger.cpp
 * @brief Implementation of TextLogger
 */

#include "../include/DataLogger/TextLogger.hpp"
#include "../include/DataLogger/LogEntry.hpp"
#include "formatting/TextFormatter.hpp"
#include "writers/FileWriter.hpp"
#include "sync/MutexGuard.hpp"
#include "sync/ProcessLock.hpp"
#include <memory>

namespace data_logger {

/**
 * @brief Private implementation of TextLogger (PIMPL pattern)
 */
class TextLogger::Impl {
public:
    Impl(const std::string& filePath, const LogConfig& config)
        : config_(config)
        , writer_(filePath, config.getTextBufferSize())
        , formatter_()
        , mutex_guard_()
        , process_lock_(nullptr) {
        
        // If no text log path was set, use the provided filePath
        if (config_.getTextLogPath().empty()) {
            config_.setTextLogPath(filePath);
        }
        
        // Create process lock if process-safe mode enabled
        if (config_.getProcessSafe()) {
            std::string lockPath = config_.getLockFilePath();
            if (lockPath.empty()) {
                // Generate lock file path from log file path
                lockPath = filePath + ".lock";
            }
            process_lock_ = std::unique_ptr<ProcessLock>(new ProcessLock(lockPath));
        }
    }
    
    void log(LogLevel level, const std::string& message) {
        // Filter by minimum level
        if (static_cast<std::uint8_t>(level) < static_cast<std::uint8_t>(config_.getMinimumLevel())) {
            return;
        }
        
        // Create log entry
        TextLogEntry entry(level, message);
        
        // Format the entry
        std::string formatted = formatter_.format(entry);
        
        // Acquire locks and write
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            if (process_lock_) {
                ProcessLockGuard plock(*process_lock_);
                writer_.write(formatted.data(), formatted.size());
            } else {
                writer_.write(formatted.data(), formatted.size());
            }
        } else if (process_lock_) {
            ProcessLockGuard plock(*process_lock_);
            writer_.write(formatted.data(), formatted.size());
        } else {
            writer_.write(formatted.data(), formatted.size());
        }
        
        // Auto-flush if level is high enough
        if (static_cast<std::uint8_t>(level) >= static_cast<std::uint8_t>(config_.getFlushOnLevel())) {
            flush();
        }
    }
    
    void flush() {
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            writer_.flush();
        } else {
            writer_.flush();
        }
    }
    
    void close() {
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            writer_.close();
        } else {
            writer_.close();
        }
    }
    
    bool isOpen() const {
        return writer_.isOpen();
    }
    
    void setMinimumLevel(LogLevel level) {
        config_.setMinimumLevel(level);
    }
    
    LogLevel getMinimumLevel() const {
        return config_.getMinimumLevel();
    }
    
private:
    LogConfig config_;
    FileWriter writer_;
    TextFormatter formatter_;
    MutexGuard mutex_guard_;
    std::unique_ptr<ProcessLock> process_lock_;
};

// TextLogger public interface implementation

TextLogger::TextLogger(const std::string& filePath)
    : impl_(new Impl(filePath, LogConfig())) {
}

TextLogger::TextLogger(const LogConfig& config)
    : impl_(new Impl(config.getTextLogPath(), config)) {
}

TextLogger::~TextLogger() = default;

TextLogger::TextLogger(TextLogger&&) noexcept = default;
TextLogger& TextLogger::operator=(TextLogger&&) noexcept = default;

void TextLogger::log(LogLevel level, const std::string& message) {
    impl_->log(level, message);
}

void TextLogger::logDebug(const std::string& message) {
    log(LogLevel::DEBUG, message);
}

void TextLogger::logInfo(const std::string& message) {
    log(LogLevel::INFO, message);
}

void TextLogger::logWarning(const std::string& message) {
    log(LogLevel::WARNING, message);
}

void TextLogger::logError(const std::string& message) {
    log(LogLevel::ERROR, message);
}

void TextLogger::logCritical(const std::string& message) {
    log(LogLevel::CRITICAL, message);
}

void TextLogger::setMinimumLevel(LogLevel level) {
    impl_->setMinimumLevel(level);
}

LogLevel TextLogger::getMinimumLevel() const {
    return impl_->getMinimumLevel();
}

void TextLogger::flush() {
    impl_->flush();
}

void TextLogger::close() {
    impl_->close();
}

bool TextLogger::isOpen() const {
    return impl_->isOpen();
}

} // namespace data_logger
