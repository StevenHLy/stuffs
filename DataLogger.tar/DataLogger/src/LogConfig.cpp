/**
 * @file LogConfig.cpp
 * @brief Implementation of LogConfig class
 */

#include "../include/DataLogger/LogConfig.hpp"
#include <unistd.h>  // for getpid()

namespace data_logger {

LogConfig::LogConfig()
    : text_log_path_()
    , trace_log_path_()
    , minimum_level_(LogLevel::DEBUG)
    , text_buffer_size_(65536)      // 64 KB default
    , trace_buffer_size_(1048576)   // 1 MB default
    , dxr_enabled_(false)
    , dxr_endpoint_()
    , dxr_config_file_()
    , dxr_text_group_id_(100)       // Default text DRG ID
    , dxr_binary_group_id_(101)     // Default binary DRG ID
    , dxr_application_id_(getpid()) // Default to process ID
    , dxr_text_buffer_pool_size_(10)    // 10 buffers
    , dxr_binary_buffer_pool_size_(10)  // 10 buffers
    , dxr_text_buffer_size_(4096)       // 4 KB per buffer
    , dxr_binary_buffer_size_(8192)     // 8 KB per buffer
    , dxr_text_ep_base_(1000)           // Text EPs: 1000-1999
    , dxr_binary_ep_base_(2000)         // Binary EPs: 2000+
    , auto_flush_ms_(0)             // Disabled by default
    , flush_on_level_(LogLevel::ERROR)
    , thread_safe_(true)            // Thread-safe by default
    , process_safe_(false)          // Process-safe disabled by default
    , lock_file_path_() {
}

void LogConfig::setTextLogPath(const std::string& path) {
    text_log_path_ = path;
}

void LogConfig::setMinimumLevel(LogLevel level) {
    minimum_level_ = level;
}

void LogConfig::setTextBufferSize(std::size_t bytes) {
    text_buffer_size_ = bytes;
}

void LogConfig::setTraceLogPath(const std::string& path) {
    trace_log_path_ = path;
}

void LogConfig::setTraceBufferSize(std::size_t bytes) {
    trace_buffer_size_ = bytes;
}

void LogConfig::setDxrEnabled(bool enabled) {
    dxr_enabled_ = enabled;
}

void LogConfig::setDxrEndpoint(const std::string& endpoint) {
    dxr_endpoint_ = endpoint;
}

void LogConfig::setDxrConfigFile(const std::string& filepath) {
    dxr_config_file_ = filepath;
}

void LogConfig::setDxrTextGroupId(unsigned int group_id) {
    dxr_text_group_id_ = group_id;
}

void LogConfig::setDxrBinaryGroupId(unsigned int group_id) {
    dxr_binary_group_id_ = group_id;
}

void LogConfig::setDxrApplicationId(unsigned int app_id) {
    dxr_application_id_ = app_id;
}

void LogConfig::setDxrTextBufferPoolSize(unsigned int num_buffers) {
    dxr_text_buffer_pool_size_ = num_buffers;
}

void LogConfig::setDxrBinaryBufferPoolSize(unsigned int num_buffers) {
    dxr_binary_buffer_pool_size_ = num_buffers;
}

void LogConfig::setDxrTextBufferSize(unsigned int buffer_bytes) {
    dxr_text_buffer_size_ = buffer_bytes;
}

void LogConfig::setDxrBinaryBufferSize(unsigned int buffer_bytes) {
    dxr_binary_buffer_size_ = buffer_bytes;
}

void LogConfig::setDxrTextEpBase(unsigned int ep_base) {
    dxr_text_ep_base_ = ep_base;
}

void LogConfig::setDxrBinaryEpBase(unsigned int ep_base) {
    dxr_binary_ep_base_ = ep_base;
}

void LogConfig::setAutoFlushInterval(std::uint32_t milliseconds) {
    auto_flush_ms_ = milliseconds;
}

void LogConfig::setFlushOnLevel(LogLevel level) {
    flush_on_level_ = level;
}

void LogConfig::setThreadSafe(bool enabled) {
    thread_safe_ = enabled;
}

void LogConfig::setProcessSafe(bool enabled) {
    process_safe_ = enabled;
}

void LogConfig::setLockFilePath(const std::string& path) {
    lock_file_path_ = path;
}

} // namespace data_logger
