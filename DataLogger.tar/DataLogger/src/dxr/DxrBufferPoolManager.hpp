/**
 * @file DxrBufferPoolManager.hpp
 * @brief Manages DXR buffer pool lifecycle (creation, attachment, cleanup)
 */

#pragma once

#ifdef HAVE_DXR
#include <dxr.h>
#endif

#include <string>
#include <cstdint>

namespace data_logger {
namespace dxr {

/**
 * @brief Manages creation, attachment, and cleanup of DXR buffer pools
 * 
 * This class handles the lifecycle of a single DXR buffer pool:
 * 1. Creates pool (if it doesn't exist)
 * 2. Attaches to pool
 * 3. Provides attachment descriptor for extraction calls
 * 4. Detaches and optionally deletes pool on destruction
 */
class DxrBufferPoolManager {
public:
    /**
     * @brief Constructor
     */
    DxrBufferPoolManager();
    
    /**
     * @brief Destructor - automatically detaches and cleans up
     */
    ~DxrBufferPoolManager();
    
    // Non-copyable, movable
    DxrBufferPoolManager(const DxrBufferPoolManager&) = delete;
    DxrBufferPoolManager& operator=(const DxrBufferPoolManager&) = delete;
    DxrBufferPoolManager(DxrBufferPoolManager&&) noexcept;
    DxrBufferPoolManager& operator=(DxrBufferPoolManager&&) noexcept;
    
    /**
     * @brief Create and attach to a DXR buffer pool
     * @param pool_name Unique name for the pool
     * @param group_id Data Recording Group ID
     * @param app_id Application identifier
     * @param num_buffers Number of buffers in pool (local and remote)
     * @param buffer_size Size of each buffer in bytes
     * @param protect_mode Protection mode (DXR_UNPROTECTED, DXR_PROC_PROTECTED, etc.)
     * @return true on success, false on failure
     */
    bool createAndAttach(
        const std::string& pool_name,
        unsigned int group_id,
        unsigned int app_id,
        unsigned int num_buffers,
        unsigned int buffer_size,
        int protect_mode
    );
    
    /**
     * @brief Detach from and optionally delete the buffer pool
     */
    void detachAndDelete();
    
    /**
     * @brief Get attachment descriptor for extraction calls
     * @return Attachment descriptor (valid only if isAttached() returns true)
     */
    int getAttachDescriptor() const { return attach_descriptor_; }
    
    /**
     * @brief Check if pool is valid and attached
     * @return true if attached to a pool
     */
    bool isAttached() const { return is_attached_; }
    
    /**
     * @brief Get pool name
     * @return Name of the buffer pool
     */
    const std::string& getPoolName() const { return pool_name_; }
    
    /**
     * @brief Flush the buffer (force immediate recording)
     * @return true on success, false on failure
     */
    bool flush();
    
private:
    std::string pool_name_;
    int attach_descriptor_;
    bool is_attached_;
    bool is_creator_;  // True if this instance created the pool
};

} // namespace dxr
} // namespace data_logger
