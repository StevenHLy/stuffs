/**
 * @file DxrDataExtractor.cpp
 * @brief Implementation of DXR data extraction operations
 */

#include "DxrDataExtractor.hpp"
#include "DxrErrorHandler.hpp"
#include <cstring>

#ifdef HAVE_DXR
#include <dxr.h>
#endif

namespace data_logger {
namespace dxr {

bool DxrDataExtractor::extractText(
    int attachdes,
    unsigned int ep_number,
    const std::string& message
) {
#ifdef HAVE_DXR
    int result = DXR_Extract(
        static_cast<DXR_attachDesType>(attachdes),
        static_cast<DXR_epNumberType>(ep_number),
        message.data(),
        message.size()
    );
    
    if (!DxrErrorHandler::isSuccess(result)) {
        DxrErrorHandler::logError(result, "DXR_Extract(text)");
        return false;
    }
    return true;
#else
    (void)attachdes; (void)ep_number; (void)message;
    return false;
#endif
}

bool DxrDataExtractor::extractBinary(
    int attachdes,
    unsigned int ep_number,
    const void* data,
    std::size_t size
) {
#ifdef HAVE_DXR
    int result = DXR_Extract(
        static_cast<DXR_attachDesType>(attachdes),
        static_cast<DXR_epNumberType>(ep_number),
        data,
        size
    );
    
    if (!DxrErrorHandler::isSuccess(result)) {
        DxrErrorHandler::logError(result, "DXR_Extract(binary)");
        return false;
    }
    return true;
#else
    (void)attachdes; (void)ep_number; (void)data; (void)size;
    return false;
#endif
}

bool DxrDataExtractor::extractWithTimestamp(
    int attachdes,
    unsigned int ep_number,
    const void* data,
    std::size_t size,
    std::uint64_t timestamp_ns
) {
#ifdef HAVE_DXR
    // Convert nanosecond timestamp to DXR format
    DXR_timeStampType dxr_ts;
    convertTimestamp(timestamp_ns, &dxr_ts);
    
    int result = DXR_ExtractWithTimeStamp(
        static_cast<DXR_attachDesType>(attachdes),
        static_cast<DXR_epNumberType>(ep_number),
        dxr_ts,
        data,
        size
    );
    
    if (!DxrErrorHandler::isSuccess(result)) {
        DxrErrorHandler::logError(result, "DXR_ExtractWithTimeStamp");
        return false;
    }
    return true;
#else
    (void)attachdes; (void)ep_number; (void)data; (void)size; (void)timestamp_ns;
    return false;
#endif
}

void DxrDataExtractor::convertTimestamp(std::uint64_t timestamp_ns, void* dxr_timestamp) {
#ifdef HAVE_DXR
    DXR_timeStampType* ts = static_cast<DXR_timeStampType*>(dxr_timestamp);
    
    // Convert nanoseconds to seconds and nanoseconds components
    const std::uint64_t BILLION = 1000000000ULL;
    ts->time_tag[0] = static_cast<unsigned int>(timestamp_ns / BILLION);  // seconds
    ts->time_tag[1] = static_cast<unsigned int>(timestamp_ns % BILLION);  // nanoseconds
    ts->clock_reset_ind = 0;  // No clock reset
#else
    (void)timestamp_ns; (void)dxr_timestamp;
#endif
}

} // namespace dxr
} // namespace data_logger
