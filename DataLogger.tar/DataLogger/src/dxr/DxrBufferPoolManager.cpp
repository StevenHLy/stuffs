/**
 * @file DxrBufferPoolManager.cpp
 * @brief Implementation of DXR buffer pool management
 */

#include "DxrBufferPoolManager.hpp"
#include "DxrErrorHandler.hpp"
#include <unistd.h>  // for usleep
#include <utility>   // for std::swap

#ifdef HAVE_DXR
#include <dxr.h>
#endif

namespace data_logger {
namespace dxr {

DxrBufferPoolManager::DxrBufferPoolManager()
    : pool_name_()
    , attach_descriptor_(-1)
    , is_attached_(false)
    , is_creator_(false) {
}

DxrBufferPoolManager::~DxrBufferPoolManager() {
    detachAndDelete();
}

DxrBufferPoolManager::DxrBufferPoolManager(DxrBufferPoolManager&& other) noexcept
    : pool_name_(std::move(other.pool_name_))
    , attach_descriptor_(other.attach_descriptor_)
    , is_attached_(other.is_attached_)
    , is_creator_(other.is_creator_) {
    // Reset other
    other.attach_descriptor_ = -1;
    other.is_attached_ = false;
    other.is_creator_ = false;
}

DxrBufferPoolManager& DxrBufferPoolManager::operator=(DxrBufferPoolManager&& other) noexcept {
    if (this != &other) {
        // Clean up our current resources
        detachAndDelete();
        
        // Move from other
        pool_name_ = std::move(other.pool_name_);
        attach_descriptor_ = other.attach_descriptor_;
        is_attached_ = other.is_attached_;
        is_creator_ = other.is_creator_;
        
        // Reset other
        other.attach_descriptor_ = -1;
        other.is_attached_ = false;
        other.is_creator_ = false;
    }
    return *this;
}

bool DxrBufferPoolManager::createAndAttach(
    const std::string& pool_name,
    unsigned int group_id,
    unsigned int app_id,
    unsigned int num_buffers,
    unsigned int buffer_size,
    int protect_mode
) {
#ifdef HAVE_DXR
    pool_name_ = pool_name;
    is_attached_ = false;
    is_creator_ = false;
    
    // First, try to attach to existing pool
    DXR_attachDesType attachdes;
    int result = DXR_AttachToPool(pool_name_.c_str(), group_id, app_id, &attachdes);
    
    if (DxrErrorHandler::isSuccess(result)) {
        // Pool exists, attached successfully
        attach_descriptor_ = attachdes;
        is_attached_ = true;
        is_creator_ = false;
        return true;
    }
    
    // Pool doesn't exist or error - try to create it
    if (result == DXR_NOPOOL || result == DXR_NOTRDY) {
        // Create new pool
        // For DataLogger we want local recording only; disable remote
        // recording by passing zeroed remote arguments as recommended
        // in the DXR User's Guide.
        result = DXR_CreateBufferPool(
            pool_name_.c_str(),
            app_id,                         // local_recording_client_id
            static_cast<int>(buffer_size),  // local_buffer_size
            static_cast<int>(num_buffers),  // number_of_local_buffers
            0,                              // local_buffer_timeout (no periodic flush)
            0,                              // remote_recording_client_id (disabled)
            0,                              // remote_buffer_size (disabled)
            0,                              // number_of_remote_buffers (disabled)
            0,                              // remote_buffer_timeout (disabled)
            static_cast<DXR_protectionModeType>(protect_mode)
        );
        
        // Handle DXR_NOTRDY - daemon may be starting
        if (result == DXR_NOTRDY) {
            // Retry a few times
            for (int retry = 0; retry < 5; ++retry) {
                usleep(100000);  // 100ms
                result = DXR_CreateBufferPool(
                    pool_name_.c_str(),
                    app_id,
                    static_cast<int>(buffer_size),
                    static_cast<int>(num_buffers),
                    0,
                    0,
                    0,
                    0,
                    0,
                    static_cast<DXR_protectionModeType>(protect_mode)
                );
                
                if (result != DXR_NOTRDY) {
                    break;
                }
            }
        }
        
        if (DxrErrorHandler::isSuccess(result)) {
            // Pool created, now attach to it
            result = DXR_AttachToPool(pool_name_.c_str(), group_id, app_id, &attachdes);
            
            if (DxrErrorHandler::isSuccess(result)) {
                attach_descriptor_ = attachdes;
                is_attached_ = true;
                is_creator_ = true;
                return true;
            } else {
                DxrErrorHandler::logError(result, "DXR_AttachToPool after creation");
                return false;
            }
        } else {
            DxrErrorHandler::logError(result, "DXR_CreateBufferPool");
            return false;
        }
    } else {
        // Unexpected error during attach
        DxrErrorHandler::logError(result, "DXR_AttachToPool");
        return false;
    }
#else
    // Stub: no DXR library available
    (void)pool_name; (void)group_id; (void)app_id;
    (void)num_buffers; (void)buffer_size; (void)protect_mode;
    return false;
#endif
}

void DxrBufferPoolManager::detachAndDelete() {
#ifdef HAVE_DXR
    if (!is_attached_) {
        return;
    }
    
    // Detach from pool
    int result = DXR_DetachFromPool(attach_descriptor_);
    if (!DxrErrorHandler::isSuccess(result)) {
        DxrErrorHandler::logError(result, "DXR_DetachFromPool", false);
    }
    
    // If we created the pool, delete it
    if (is_creator_) {
        result = DXR_DeleteBufferPool(pool_name_.c_str());
        if (!DxrErrorHandler::isSuccess(result)) {
            DxrErrorHandler::logError(result, "DXR_DeleteBufferPool", false);
        }
    }
    
    is_attached_ = false;
    is_creator_ = false;
    attach_descriptor_ = -1;
#endif
}

bool DxrBufferPoolManager::flush() {
#ifdef HAVE_DXR
    if (!is_attached_) {
        return false;
    }
    
    int result = DXR_FlushBuffer(attach_descriptor_);
    if (!DxrErrorHandler::isSuccess(result)) {
        DxrErrorHandler::logError(result, "DXR_FlushBuffer");
        return false;
    }
    return true;
#else
    return false;
#endif
}

} // namespace dxr
} // namespace data_logger
