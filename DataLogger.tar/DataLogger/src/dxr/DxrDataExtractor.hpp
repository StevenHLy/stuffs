/**
 * @file DxrDataExtractor.hpp
 * @brief Handles data extraction to DXR buffer pools
 */

#pragma once

#ifdef HAVE_DXR
#include <dxr.h>
#endif

#include <string>
#include <cstdint>
#include <cstddef>

namespace data_logger {
namespace dxr {

/**
 * @brief Extracts data to DXR buffer pools
 * 
 * This class provides static methods for extracting various types of data
 * to DXR buffer pools using the Data Extraction API.
 */
class DxrDataExtractor {
public:
    /**
     * @brief Extract text message to DXR
     * @param attachdes Buffer pool attachment descriptor
     * @param ep_number Extraction point number
     * @param message Text message to extract
     * @return true on success, false on failure
     */
    static bool extractText(
        int attachdes,
        unsigned int ep_number,
        const std::string& message
    );
    
    /**
     * @brief Extract binary message to DXR
     * @param attachdes Buffer pool attachment descriptor
     * @param ep_number Extraction point number (typically message_id)
     * @param data Pointer to binary data
     * @param size Size of data in bytes
     * @return true on success, false on failure
     */
    static bool extractBinary(
        int attachdes,
        unsigned int ep_number,
        const void* data,
        std::size_t size
    );
    
    /**
     * @brief Extract with custom timestamp
     * @param attachdes Buffer pool attachment descriptor
     * @param ep_number Extraction point number
     * @param data Pointer to data
     * @param size Size of data in bytes
     * @param timestamp_ns Timestamp in nanoseconds since epoch
     * @return true on success, false on failure
     */
    static bool extractWithTimestamp(
        int attachdes,
        unsigned int ep_number,
        const void* data,
        std::size_t size,
        std::uint64_t timestamp_ns
    );

private:
    /**
     * @brief Convert nanosecond timestamp to DXR format
     * @param timestamp_ns Nanoseconds since epoch
     * @return DXR timestamp structure
     */
    static void convertTimestamp(std::uint64_t timestamp_ns, void* dxr_timestamp);
};

} // namespace dxr
} // namespace data_logger
