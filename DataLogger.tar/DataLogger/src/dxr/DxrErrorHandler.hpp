/**
 * @file DxrErrorHandler.hpp
 * @brief Maps DXR error codes to readable messages and provides error handling utilities
 */

#pragma once

#include <string>

namespace data_logger {
namespace dxr {

/**
 * @brief Handles DXR error codes and provides logging/reporting utilities
 */
class DxrErrorHandler {
public:
    /**
     * @brief Convert DXR error code to human-readable string
     * @param error_code DXR error code (e.g., DXR_SUCCESS, DXR_NOTRDY, etc.)
     * @return Descriptive error message
     */
    static std::string errorToString(int error_code);
    
    /**
     * @brief Log a DXR error with context
     * @param error_code DXR error code
     * @param context Descriptive context (function name, operation, etc.)
     * @param log_warnings If true, log warnings for non-fatal errors
     */
    static void logError(int error_code, const std::string& context, bool log_warnings = true);
    
    /**
     * @brief Check if error code indicates success
     * @param error_code DXR error code
     * @return true if error_code == DXR_SUCCESS (0)
     */
    static bool isSuccess(int error_code);
    
    /**
     * @brief Check if error is recoverable
     * @param error_code DXR error code
     * @return true if error is recoverable (e.g., DXR_NOTRDY, DXR_OVERFLOW)
     */
    static bool isRecoverable(int error_code);
    
    /**
     * @brief Check if error is fatal (requires shutdown)
     * @param error_code DXR error code
     * @return true if error requires immediate shutdown
     */
    static bool isFatal(int error_code);
};

} // namespace dxr
} // namespace data_logger
