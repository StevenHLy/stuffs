/**
 * @file DxrErrorHandler.cpp
 * @brief Implementation of DXR error handling utilities
 */

#include "DxrErrorHandler.hpp"
#include <iostream>

#ifdef HAVE_DXR
#include <dxr.h>
#endif

namespace data_logger {
namespace dxr {

std::string DxrErrorHandler::errorToString(int error_code) {
#ifdef HAVE_DXR
    switch (error_code) {
        case DXR_SUCCESS:
            return "SUCCESS: Operation completed successfully";
        case DXR_ARRAYSIZE:
            return "ARRAYSIZE: Invalid array size";
        case DXR_BADDES:
            return "BADDES: Invalid attachment descriptor";
        case DXR_BADDEV:
            return "BADDEV: Invalid device";
        case DXR_BADENV:
            return "BADENV: Invalid environment variable or configuration";
        case DXR_BADEP:
            return "BADEP: Invalid extraction point number";
        case DXR_BADEPSET:
            return "BADEPSET: Invalid EP set identifier";
        case DXR_BADFD:
            return "BADFD: Invalid file descriptor";
        case DXR_BADGROUP:
            return "BADGROUP: Invalid Data Recording Group ID";
        case DXR_BADHOST:
            return "BADHOST: Invalid hostname";
        case DXR_BADLABEL:
            return "BADLABEL: Invalid label";
        case DXR_BADMOD:
            return "BADMOD: Invalid modification";
        case DXR_BADMODE:
            return "BADMODE: Invalid mode";
        case DXR_BADNOTE:
            return "BADNOTE: Invalid operator note";
        case DXR_BADPARTITION:
            return "BADPARTITION: Invalid partition";
        case DXR_BADPOOL:
            return "BADPOOL: Invalid buffer pool name";
        case DXR_BADSIZE:
            return "BADSIZE: Invalid size parameter";
        case DXR_BADSTATE:
            return "BADSTATE: Invalid state";
        case DXR_BADTESTID:
            return "BADTESTID: Invalid test identifier";
        case DXR_BADTIME:
            return "BADTIME: Invalid time parameter";
        case DXR_EXISTS:
            return "EXISTS: Object already exists";
        case DXR_FAILURE:
            return "FAILURE: General failure";
        case DXR_INVALIDOP:
            return "INVALIDOP: Invalid operation";
        case DXR_MAXPOOLS:
            return "MAXPOOLS: Maximum number of pools reached";
        case DXR_NOEVID:
            return "NOEVID: No executable version ID available";
        case DXR_NOPOOL:
            return "NOPOOL: Buffer pool does not exist";
        case DXR_NOSERVER:
            return "NOSERVER: Cannot connect to DXR Control Server";
        case DXR_NOSPACE:
            return "NOSPACE: No space available";
        case DXR_NOTIMEOUT:
            return "NOTIMEOUT: No timeout (used as parameter value)";
        case DXR_NOTRDY:
            return "NOTRDY: DXR daemon not ready (may be starting or not running)";
        case DXR_OVERFLOW:
            return "OVERFLOW: Buffer pool overflow - data may be lost";
        case DXR_TOOBIG:
            return "TOOBIG: Data size exceeds buffer capacity";
        case DXR_DELETEPENDING:
            return "DELETEPENDING: Deletion is pending";
        default:
            return "UNKNOWN: Unknown error code (" + std::to_string(error_code) + ")";
    }
#else
    (void)error_code;
    return "DXR not available (compiled without HAVE_DXR)";
#endif
}

bool DxrErrorHandler::isSuccess(int error_code) {
#ifdef HAVE_DXR
    return error_code == DXR_SUCCESS;
#else
    (void)error_code;
    return false;
#endif
}

bool DxrErrorHandler::isRecoverable(int error_code) {
#ifdef HAVE_DXR
    switch (error_code) {
        case DXR_NOTRDY:      // Daemon not ready - can retry
        case DXR_OVERFLOW:    // Buffer overflow - warning but can continue
        case DXR_NOSERVER:    // Server not available - can retry
            return true;
        default:
            return false;
    }
#else
    (void)error_code;
    return false;
#endif
}

bool DxrErrorHandler::isFatal(int error_code) {
#ifdef HAVE_DXR
    switch (error_code) {
        case DXR_FAILURE:
        case DXR_NOSPACE:
        case DXR_TOOBIG:
            return true;
        default:
            return false;
    }
#else
    (void)error_code;
    return false;
#endif
}

void DxrErrorHandler::logError(int error_code, const std::string& context, bool log_warnings) {
    if (isSuccess(error_code)) {
        return;  // No error to log
    }
    
    std::string message = "DXR Error in " + context + ": " + errorToString(error_code);
    
    if (isFatal(error_code)) {
        std::cerr << "[FATAL] " << message << std::endl;
    } else if (isRecoverable(error_code) && log_warnings) {
        std::cerr << "[WARNING] " << message << std::endl;
    } else if (log_warnings) {
        std::cerr << "[ERROR] " << message << std::endl;
    }
}

} // namespace dxr
} // namespace data_logger
