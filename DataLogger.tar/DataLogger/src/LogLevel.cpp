/**
 * @file LogLevel.cpp
 * @brief Implementation of LogLevel utilities
 */

#include "../include/DataLogger/LogLevel.hpp"
#include <algorithm>
#include <cctype>
#include <stdexcept>

namespace data_logger {

const char* toString(LogLevel level) {
    switch (level) {
        case LogLevel::DEBUG:    return "DEBUG";
        case LogLevel::INFO:     return "INFO";
        case LogLevel::WARNING:  return "WARNING";
        case LogLevel::ERROR:    return "ERROR";
        case LogLevel::CRITICAL: return "CRITICAL";
        default:                 return "UNKNOWN";
    }
}

LogLevel fromString(const std::string& levelStr) {
    // Convert to uppercase for case-insensitive comparison
    std::string upper = levelStr;
    std::transform(upper.begin(), upper.end(), upper.begin(), 
                   [](unsigned char c) { return std::toupper(c); });
    
    if (upper == "DEBUG")    return LogLevel::DEBUG;
    if (upper == "INFO")     return LogLevel::INFO;
    if (upper == "WARNING")  return LogLevel::WARNING;
    if (upper == "WARN")     return LogLevel::WARNING;  // Accept "WARN" as alias
    if (upper == "ERROR")    return LogLevel::ERROR;
    if (upper == "CRITICAL") return LogLevel::CRITICAL;
    if (upper == "CRIT")     return LogLevel::CRITICAL; // Accept "CRIT" as alias
    
    throw std::invalid_argument("Invalid log level string: " + levelStr);
}

} // namespace data_logger
