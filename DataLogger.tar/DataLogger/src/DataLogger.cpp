/**
 * @file DataLogger.cpp
 * @brief Implementation of static DataLogger facade
 */

#include "../include/DataLogger/DataLogger.hpp"
#include <memory>
#include <mutex>

namespace data_logger {

namespace {
    // Singleton instances for static convenience methods
    std::unique_ptr<TextLogger> g_text_logger;
    std::unique_ptr<TraceLogger> g_trace_logger;
    std::mutex g_mutex;
    LogConfig g_config;
    bool g_configured = false;
    
    // Default log paths
    const std::string DEFAULT_TEXT_LOG = "datalogger_text.log";
    const std::string DEFAULT_TRACE_LOG = "datalogger_trace.bin";
    
    /**
     * @brief Ensure default loggers are initialized
     */
    void ensureInitialized() {
        std::lock_guard<std::mutex> lock(g_mutex);
        
        if (!g_configured) {
            // Set default paths
            g_config.setTextLogPath(DEFAULT_TEXT_LOG);
            g_config.setTraceLogPath(DEFAULT_TRACE_LOG);
            g_configured = true;
        }
        
        if (!g_text_logger) {
            g_text_logger = std::unique_ptr<TextLogger>(new TextLogger(g_config));
        }
        
        if (!g_trace_logger) {
            g_trace_logger = std::unique_ptr<TraceLogger>(new TraceLogger(g_config));
        }
    }
} // anonymous namespace

// Static convenience methods for text logging

void DataLogger::logInfo(const std::string& message) {
    ensureInitialized();
    g_text_logger->logInfo(message);
}

void DataLogger::logWarning(const std::string& message) {
    ensureInitialized();
    g_text_logger->logWarning(message);
}

void DataLogger::logError(const std::string& message) {
    ensureInitialized();
    g_text_logger->logError(message);
}

void DataLogger::logDebug(const std::string& message) {
    ensureInitialized();
    g_text_logger->logDebug(message);
}

void DataLogger::logCritical(const std::string& message) {
    ensureInitialized();
    g_text_logger->logCritical(message);
}

// Static convenience method for binary trace logging

void DataLogger::logTrace(std::uint32_t messageId, const void* data, std::size_t size) {
    ensureInitialized();
    g_trace_logger->logTrace(messageId, data, size);
}

// Configuration and control

void DataLogger::configure(const LogConfig& config) {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    g_config = config;
    g_configured = true;
    
    // Recreate loggers with new configuration
    g_text_logger.reset();
    g_trace_logger.reset();
    
    if (!g_config.getTextLogPath().empty()) {
        g_text_logger = std::unique_ptr<TextLogger>(new TextLogger(g_config));
    }
    
    if (!g_config.getTraceLogPath().empty()) {
        g_trace_logger = std::unique_ptr<TraceLogger>(new TraceLogger(g_config));
    }
}

void DataLogger::flush() {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    if (g_text_logger) {
        g_text_logger->flush();
    }
    
    if (g_trace_logger) {
        g_trace_logger->flush();
    }
}

void DataLogger::shutdown() {
    std::lock_guard<std::mutex> lock(g_mutex);
    
    if (g_text_logger) {
        g_text_logger->close();
        g_text_logger.reset();
    }
    
    if (g_trace_logger) {
        g_trace_logger->close();
        g_trace_logger.reset();
    }
    
    g_configured = false;
}

// Factory methods for instance-based usage

std::unique_ptr<TextLogger> DataLogger::createTextLogger(const std::string& filePath) {
    return std::unique_ptr<TextLogger>(new TextLogger(filePath));
}

std::unique_ptr<TextLogger> DataLogger::createTextLogger(const LogConfig& config) {
    return std::unique_ptr<TextLogger>(new TextLogger(config));
}

std::unique_ptr<TraceLogger> DataLogger::createTraceLogger(const std::string& filePath) {
    return std::unique_ptr<TraceLogger>(new TraceLogger(filePath));
}

std::unique_ptr<TraceLogger> DataLogger::createTraceLogger(const LogConfig& config) {
    return std::unique_ptr<TraceLogger>(new TraceLogger(config));
}

std::unique_ptr<DxrLogger> DataLogger::createDxrLogger(const LogConfig& config) {
    return std::unique_ptr<DxrLogger>(new DxrLogger(config));
}

} // namespace data_logger
