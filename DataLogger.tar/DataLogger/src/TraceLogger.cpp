/**
 * @file TraceLogger.cpp
 * @brief Implementation of TraceLogger
 */

#include "../include/DataLogger/TraceLogger.hpp"
#include "../include/DataLogger/LogEntry.hpp"
#include "formatting/BinaryFormatter.hpp"
#include "writers/FileWriter.hpp"
#include "sync/MutexGuard.hpp"
#include "sync/ProcessLock.hpp"
#include <chrono>
#include <memory>

namespace data_logger {

/**
 * @brief Private implementation of TraceLogger (PIMPL pattern)
 */
class TraceLogger::Impl {
public:
    Impl(const std::string& filePath, const LogConfig& config)
        : config_(config)
        , writer_(filePath, config.getTraceBufferSize())
        , formatter_()
        , mutex_guard_()
        , process_lock_(nullptr)
        , header_written_(false) {
        
        // If no trace log path was set, use the provided filePath
        if (config_.getTraceLogPath().empty()) {
            config_.setTraceLogPath(filePath);
        }
        
        // Create process lock if process-safe mode enabled
        if (config_.getProcessSafe()) {
            std::string lockPath = config_.getLockFilePath();
            if (lockPath.empty()) {
                // Generate lock file path from log file path
                lockPath = filePath + ".lock";
            }
            process_lock_ = std::unique_ptr<ProcessLock>(new ProcessLock(lockPath));
        }
    }
    
    void logTrace(std::uint32_t messageId, const void* data, std::size_t size) {
        // Write file header on first entry
        if (!header_written_) {
            writeHeader();
        }
        
        // Create trace entry
        TraceLogEntry entry(messageId, data, size);
        
        // Acquire locks and write
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            if (process_lock_) {
                ProcessLockGuard plock(*process_lock_);
                formatter_.writeEntry(writer_, entry);
            } else {
                formatter_.writeEntry(writer_, entry);
            }
        } else if (process_lock_) {
            ProcessLockGuard plock(*process_lock_);
            formatter_.writeEntry(writer_, entry);
        } else {
            formatter_.writeEntry(writer_, entry);
        }
    }
    
    void flush() {
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            writer_.flush();
        } else {
            writer_.flush();
        }
    }
    
    void close() {
        if (config_.getThreadSafe()) {
            ScopedLock lock(mutex_guard_);
            writer_.close();
        } else {
            writer_.close();
        }
    }
    
    bool isOpen() const {
        return writer_.isOpen();
    }
    
private:
    void writeHeader() {
        if (!header_written_) {
            auto now = std::chrono::system_clock::now();
            auto duration = now.time_since_epoch();
            std::uint64_t timestamp = std::chrono::duration_cast<std::chrono::nanoseconds>(duration).count();
            
            formatter_.writeFileHeader(writer_, timestamp);
            header_written_ = true;
        }
    }
    
    LogConfig config_;
    FileWriter writer_;
    BinaryFormatter formatter_;
    MutexGuard mutex_guard_;
    std::unique_ptr<ProcessLock> process_lock_;
    bool header_written_;
};

// TraceLogger public interface implementation

TraceLogger::TraceLogger(const std::string& filePath)
    : impl_(new Impl(filePath, LogConfig())) {
}

TraceLogger::TraceLogger(const LogConfig& config)
    : impl_(new Impl(config.getTraceLogPath(), config)) {
}

TraceLogger::~TraceLogger() = default;

TraceLogger::TraceLogger(TraceLogger&&) noexcept = default;
TraceLogger& TraceLogger::operator=(TraceLogger&&) noexcept = default;

void TraceLogger::logTrace(std::uint32_t messageId, const void* data, std::size_t size) {
    impl_->logTrace(messageId, data, size);
}

void TraceLogger::flush() {
    impl_->flush();
}

void TraceLogger::close() {
    impl_->close();
}

bool TraceLogger::isOpen() const {
    return impl_->isOpen();
}

} // namespace data_logger
