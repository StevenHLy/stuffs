/**
 * @file DxrLogger.cpp
 * @brief Full implementation of DXR logger integration
 */

#include "../include/DataLogger/DxrLogger.hpp"
#include "../include/DataLogger/DxrConfig.hpp"
#include "dxr/DxrBufferPoolManager.hpp"
#include "dxr/DxrDataExtractor.hpp"
#include "dxr/DxrErrorHandler.hpp"

#ifdef HAVE_DXR
#include <dxr.h>
#endif

#include <memory>
#include <string>
#include <cstdlib>  // for setenv

namespace data_logger {

/**
 * @brief Private implementation of DxrLogger (PIMPL pattern)
 * 
 * Manages two separate buffer pools:
 * - Text pool for text messages
 * - Binary pool for binary trace data
 */
class DxrLogger::Impl {
public:
    explicit Impl(const LogConfig& config)
        : config_(config)
        , initialized_(false)
        , connected_(false)
        , text_pool_()
        , binary_pool_()
        , next_text_ep_(0) {
    }
    
    ~Impl() {
        shutdown();
    }
    
    void initialize() {
        if (initialized_) {
            return;  // Already initialized
        }
        
#ifdef HAVE_DXR
        if (!config_.getDxrEnabled()) {
            return;  // DXR disabled
        }
        
        // Setup environment if config file specified
        setupEnvironment();
        
        // Create buffer pools
        bool success = createPools();
        
        if (success) {
            initialized_ = true;
            connected_ = true;
        } else {
            // Failed to create pools - DXR daemon likely not running
            // This is not fatal, log warning but continue
            dxr::DxrErrorHandler::logError(DXR_NOTRDY, "DxrLogger initialization", true);
            initialized_ = true;
            connected_ = false;
        }
#else
        // DXR not available at compile time
        initialized_ = false;
        connected_ = false;
#endif
    }
    
    void logMessage(const std::string& message) {
        if (!connected_ || !config_.getDxrEnabled()) {
            return;  // Not connected or disabled
        }
        
#ifdef HAVE_DXR
        // Use text pool with incrementing EP numbers
        unsigned int ep_number = config_.getDxrTextEpBase() + next_text_ep_;
        next_text_ep_ = (next_text_ep_ + 1) % 1000;  // Wrap after 1000 messages
        
        dxr::DxrDataExtractor::extractText(
            text_pool_->getAttachDescriptor(),
            ep_number,
            message
        );
#else
        (void)message;
#endif
    }
    
    void logMessage(std::uint32_t messageId, const void* data, std::size_t size) {
        if (!connected_ || !config_.getDxrEnabled()) {
            return;  // Not connected or disabled
        }
        
#ifdef HAVE_DXR
        // Use binary pool with message ID as EP number (offset by base)
        unsigned int ep_number = config_.getDxrBinaryEpBase() + messageId;
        
        dxr::DxrDataExtractor::extractBinary(
            binary_pool_->getAttachDescriptor(),
            ep_number,
            data,
            size
        );
#else
        (void)messageId; (void)data; (void)size;
#endif
    }
    
    void shutdown() {
        if (!initialized_) {
            return;
        }
        
#ifdef HAVE_DXR
        // Detach and delete pools
        if (text_pool_) {
            text_pool_->detachAndDelete();
        }
        if (binary_pool_) {
            binary_pool_->detachAndDelete();
        }
#endif
        
        connected_ = false;
        initialized_ = false;
    }
    
    bool isConnected() const {
        return connected_;
    }
    
private:
    void setupEnvironment() {
#ifdef HAVE_DXR
        // Set DXR_CONFIG_FILE environment variable if specified
        if (!config_.getDxrConfigFile().empty()) {
            setenv("DXR_CONFIG_FILE", config_.getDxrConfigFile().c_str(), 1);
        }
#endif
    }
    
    bool createPools() {
#ifdef HAVE_DXR
        // Determine protection mode based on config
        int protect_mode = DXR_UNPROTECTED;
        if (config_.getProcessSafe()) {
            protect_mode = DXR_PROCESS_PROTECTED;
        } else if (config_.getThreadSafe()) {
            protect_mode = DXR_PTHREAD_PROTECTED;
        }
        
        // Create text buffer pool
        text_pool_ = std::unique_ptr<dxr::DxrBufferPoolManager>(
            new dxr::DxrBufferPoolManager()
        );
        
        bool text_success = text_pool_->createAndAttach(
            "datalogger_text_pool",
            config_.getDxrTextGroupId(),
            config_.getDxrApplicationId(),
            config_.getDxrTextBufferPoolSize(),
            config_.getDxrTextBufferSize(),
            protect_mode
        );
        
        if (!text_success) {
            return false;
        }
        
        // Create binary buffer pool
        binary_pool_ = std::unique_ptr<dxr::DxrBufferPoolManager>(
            new dxr::DxrBufferPoolManager()
        );
        
        bool binary_success = binary_pool_->createAndAttach(
            "datalogger_binary_pool",
            config_.getDxrBinaryGroupId(),
            config_.getDxrApplicationId(),
            config_.getDxrBinaryBufferPoolSize(),
            config_.getDxrBinaryBufferSize(),
            protect_mode
        );
        
        if (!binary_success) {
            // Clean up text pool
            text_pool_->detachAndDelete();
            return false;
        }
        
        return true;
#else
        return false;
#endif
    }
    
    LogConfig config_;
    bool initialized_;
    bool connected_;
    
    std::unique_ptr<dxr::DxrBufferPoolManager> text_pool_;
    std::unique_ptr<dxr::DxrBufferPoolManager> binary_pool_;
    
    unsigned int next_text_ep_;  // Counter for text EP numbers
};

// DxrLogger public interface implementation

DxrLogger::DxrLogger(const LogConfig& config)
    : impl_(new Impl(config)) {
}

DxrLogger::~DxrLogger() = default;

DxrLogger::DxrLogger(DxrLogger&&) noexcept = default;
DxrLogger& DxrLogger::operator=(DxrLogger&&) noexcept = default;

void DxrLogger::initialize() {
    impl_->initialize();
}

void DxrLogger::logMessage(const std::string& message) {
    impl_->logMessage(message);
}

void DxrLogger::logMessage(std::uint32_t messageId, const void* data, std::size_t size) {
    impl_->logMessage(messageId, data, size);
}

void DxrLogger::shutdown() {
    impl_->shutdown();
}

bool DxrLogger::isConnected() const {
    return impl_->isConnected();
}

} // namespace data_logger
