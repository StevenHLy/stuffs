/**
 * @file dxr_example.cpp
 * @brief Example program demonstrating DXR integration with DataLogger
 * 
 * This program shows how to:
 * 1. Configure DXR logging
 * 2. Initialize DXR connection
 * 3. Log text messages to DXR
 * 4. Log binary data to DXR
 * 5. Handle DXR errors gracefully
 */

#include "DataLogger/DxrLogger.hpp"
#include "DataLogger/LogConfig.hpp"
#include "DataLogger/DxrConfig.hpp"

#include <iostream>
#include <thread>
#include <chrono>
#include <cstdint>

using namespace data_logger;

void printConfiguration(const LogConfig& config) {
    std::cout << "\n=== DXR Configuration ===" << std::endl;
    std::cout << "  Enabled: " << (config.getDxrEnabled() ? "Yes" : "No") << std::endl;
    std::cout << "  Endpoint: " << config.getDxrEndpoint() << std::endl;
    std::cout << "  Config File: " << (config.getDxrConfigFile().empty() ? "(none)" : config.getDxrConfigFile()) << std::endl;
    std::cout << "  Text Group ID: " << config.getDxrTextGroupId() << std::endl;
    std::cout << "  Binary Group ID: " << config.getDxrBinaryGroupId() << std::endl;
    std::cout << "  Application ID: " << config.getDxrApplicationId() << std::endl;
    std::cout << "  Text Buffer Pool: " << config.getDxrTextBufferPoolSize() 
              << " buffers × " << config.getDxrTextBufferSize() << " bytes" << std::endl;
    std::cout << "  Binary Buffer Pool: " << config.getDxrBinaryBufferPoolSize() 
              << " buffers × " << config.getDxrBinaryBufferSize() << " bytes" << std::endl;
    std::cout << "  Text EP Base: " << config.getDxrTextEpBase() << std::endl;
    std::cout << "  Binary EP Base: " << config.getDxrBinaryEpBase() << std::endl;
    std::cout << "  Thread Safe: " << (config.getThreadSafe() ? "Yes" : "No") << std::endl;
    std::cout << "  Process Safe: " << (config.getProcessSafe() ? "Yes" : "No") << std::endl;
}

int main(int argc, char* argv[]) {
    std::cout << "========================================" << std::endl;
    std::cout << "DataLogger DXR Integration Example" << std::endl;
    std::cout << "========================================" << std::endl;
    
    // Check if DXR is available at compile time
    if (!dxr::isAvailable()) {
        std::cout << "\n❌ DXR is not available (compiled without HAVE_DXR)" << std::endl;
        std::cout << "   DXR libraries were not found during build." << std::endl;
        return 1;
    }
    
    std::cout << "\n✅ DXR is available!" << std::endl;
    
    // Create configuration
    LogConfig config;
    
    // Enable DXR
    config.setDxrEnabled(true);
    
    // Set recording client ID to match LRC CLIENT_IDS configuration (1-100)
    config.setDxrApplicationId(1);  // Must match CLIENT_IDS in dxr.conf
    
    // Set DRG ID for binary logging (Group 100)
    config.setDxrBinaryGroupId(100);
    config.setDxrBinaryEpBase(1000);
    
    // Optional: Set DXR endpoint (hostname:port of Control Server)
    // config.setDxrEndpoint("localhost:5000");
    
    // Optional: Set DXR configuration file
    // config.setDxrConfigFile("/etc/dxr/datalogger.conf");
    
    // Optional: Customize DXR settings
    // config.setDxrTextGroupId(100);
    // config.setDxrBinaryGroupId(101);
    // config.setDxrTextBufferPoolSize(20);  // More buffers for high-rate logging
    
    // Optional: Enable thread/process safety
    config.setThreadSafe(true);   // Thread-safe (uses pthread mutex in DXR)
    config.setProcessSafe(false); // Process-safe (uses file locking in DXR)
    
    printConfiguration(config);
    
    // Create DXR logger
    std::cout << "\n=== Creating DXR Logger ===" << std::endl;
    DxrLogger logger(config);
    
    // Initialize connection
    std::cout << "Initializing DXR connection..." << std::endl;
    logger.initialize();
    
    if (logger.isConnected()) {
        std::cout << "✅ Connected to DXR!" << std::endl;
        std::cout << "   Data will be recorded to configured DXR destinations." << std::endl;
    } else {
        std::cout << "⚠️  Not connected to DXR (daemon may not be running)" << std::endl;
        std::cout << "   This is not an error - the example will continue." << std::endl;
        std::cout << "   To enable actual recording, start the DXR daemon:" << std::endl;
        std::cout << "     $ dxr_daemon --config /path/to/dxr.conf" << std::endl;
    }
    
    // Example 1: Log binary sensor data
    std::cout << "\n=== Example 1: Binary Sensor Data ===" << std::endl;
    std::cout << "Logging 10 binary sensor messages..." << std::endl;
    
    struct SensorData {
        uint32_t timestamp;
        float temperature;
        float pressure;
        uint16_t sensor_id;
        uint16_t status;
    };
    
    for (int i = 0; i < 10; ++i) {
        SensorData data;
        data.timestamp = static_cast<uint32_t>(i * 1000);
        data.temperature = 20.0f + static_cast<float>(i) * 0.5f;
        data.pressure = 1013.25f + static_cast<float>(i) * 0.1f;
        data.sensor_id = 42;
        data.status = 0x01;  // OK
        
        // Each message needs unique EP number (1001, 1002, 1003 as configured)
        uint32_t ep_number = 1001 + i;
        logger.logMessage(ep_number, &data, sizeof(data));
        
        std::cout << "  [" << i << "] Logged binary: EP=" << ep_number
                  << " temp=" << data.temperature 
                  << "°C pressure=" << data.pressure << " mbar" << std::endl;
        std::this_thread::sleep_for(std::chrono::milliseconds(50));
    }
    
    // Example 2: High-rate binary logging
    std::cout << "\n=== Example 2: High-Rate Binary Logging ===" << std::endl;
    std::cout << "Logging 100 messages as fast as possible..." << std::endl;
    
    auto start = std::chrono::high_resolution_clock::now();
    
    for (int i = 0; i < 100; ++i) {
        uint64_t data = 0xCAFEBABE00000000ULL | i;
        // Use EPs in configured range (1001, 1002, 1003 - cycle through them)
        uint32_t ep = 1001 + (i % 3);
        logger.logMessage(ep, &data, sizeof(data));
    }
    
    auto end = std::chrono::high_resolution_clock::now();
    auto duration = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    
    double msgs_per_sec = 100.0 / (duration.count() / 1000000.0);
    std::cout << "  ✅ Logged 100 messages in " << duration.count() / 1000.0 << " ms" << std::endl;
    std::cout << "  Throughput: " << static_cast<int>(msgs_per_sec) << " messages/second" << std::endl;
    
    // Shutdown
    std::cout << "\n=== Shutting Down ===" << std::endl;
    std::cout << "Closing DXR connection..." << std::endl;
    logger.shutdown();
    std::cout << "✅ Shutdown complete" << std::endl;
    
    // Summary
    std::cout << "\n========================================" << std::endl;
    std::cout << "Example Complete!" << std::endl;
    std::cout << "========================================" << std::endl;
    std::cout << "\nWhat happened:" << std::endl;
    std::cout << "  • Configured DXR for binary data recording" << std::endl;
    std::cout << "  • Logged " << (10 + 100) << " binary messages total" << std::endl;
    std::cout << "  • Used EP numbers 1001, 1002, 1003 (as configured in DRG)" << std::endl;
    std::cout << "  • Demonstrated graceful handling if daemon not running" << std::endl;
    
    if (logger.isConnected()) {
        std::cout << "\n✅ Recording successful!" << std::endl;
        std::cout << "   Check DXR recording files for extracted data." << std::endl;
    } else {
        std::cout << "\n⚠️  DXR daemon was not running during this example." << std::endl;
        std::cout << "   To see actual recording:" << std::endl;
        std::cout << "   1. Start DXR daemon: dxr_daemon --config /path/to/dxr.conf" << std::endl;
        std::cout << "   2. Run this example again" << std::endl;
        std::cout << "   3. Check recording files: /var/log/dxr/*.cdrf" << std::endl;
    }
    
    std::cout << "\nFor more information, see:" << std::endl;
    std::cout << "  • DataLogger/README.md" << std::endl;
    std::cout << "  • DataLogger/DXR_INTEGRATION.md" << std::endl;
    std::cout << "  • dxr_user_guide.pdf" << std::endl;
    
    return 0;
}
