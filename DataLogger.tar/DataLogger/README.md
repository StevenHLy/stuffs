# DataLogger CommonModule

A high-performance, thread-safe and process-safe logging library for C++ applications.

## Architecture

**Quick Overview**: See [`DataLogger_Overview.png`](DataLogger_Overview.png) for a high-level component diagram.

**Detailed Design**: See [`DataLogger_Class_Diagram.png`](DataLogger_Class_Diagram.png) for the complete UML class diagram.

**Architecture Documentation**: See [`ARCHITECTURE.md`](ARCHITECTURE.md) for detailed design patterns, data flows, and implementation details.

## Overview

DataLogger provides three main logging capabilities:

1. **Text Logging** - Structured log messages with timestamps, severity levels, and formatted output
2. **Binary Trace Logging** - High-performance binary message logging with metadata
3. **DXR Integration** - Full integration with DXR (Data Extraction and Recording) system for centralized, distributed recording

## Features

- **Thread-safe** - Use mutexes for safe concurrent logging from multiple threads
- **Process-safe** - File-based locking for multi-process logging (NFS-compatible)
- **Buffered I/O** - Configurable write buffering for optimal performance
- **Multiple API styles** - Both instance-based and static convenience methods
- **Configurable** - Extensive configuration options via `LogConfig`
- **Exception-based error handling** - Clear error reporting matching codebase conventions
- **DXR Integration** - Native support for distributed recording with centralized control

## Quick Start

### Text Logging (Simple)

```cpp
#include "DataLogger/DataLogger.hpp"

// Use static convenience methods
data_logger::DataLogger::logInfo("Application started");
data_logger::DataLogger::logWarning("Resource usage high");
data_logger::DataLogger::logError("Failed to connect");
data_logger::DataLogger::flush();
```

### Text Logging (Instance-based)

```cpp
#include "DataLogger/TextLogger.hpp"

auto logger = data_logger::DataLogger::createTextLogger("/var/log/myapp.log");

logger->logInfo("User logged in");
logger->logDebug("Processing request ID: 12345");
logger->logError("Database connection failed");

logger->flush();
logger->close();
```

### Binary Trace Logging

```cpp
#include "DataLogger/TraceLogger.hpp"

auto tracer = data_logger::DataLogger::createTraceLogger("/var/log/trace.bin");

// Log structured data
struct SensorData {
    uint64_t timestamp;
    double temperature;
    double pressure;
} data = {1234567890, 25.3, 1013.25};

tracer->logTrace(1001, &data, sizeof(data));

// Or use template convenience
uint32_t eventId = 42;
tracer->logTrace(1002, eventId);

tracer->close();
```

### DXR Logging (Distributed Recording)

```cpp
#include "DataLogger/DxrLogger.hpp"
#include "DataLogger/LogConfig.hpp"

// Configure DXR
data_logger::LogConfig config;
config.setDxrEnabled(true);
config.setDxrEndpoint("control-server:5000");  // Optional

// Create and initialize
data_logger::DxrLogger logger(config);
logger.initialize();

// Check connection
if (logger.isConnected()) {
    // Log text messages
    logger.logMessage("System event occurred");
    
    // Log binary data
    uint64_t sensor_data = 0xCAFEBABE;
    logger.logMessage(1001, &sensor_data, sizeof(sensor_data));
}

logger.shutdown();
```

**See [DXR_INTEGRATION.md](DXR_INTEGRATION.md) for complete DXR documentation.**

### Configuration

```cpp
#include "DataLogger/LogConfig.hpp"

data_logger::LogConfig config;

// Text logging configuration
config.setTextLogPath("/var/log/myapp.log");
config.setMinimumLevel(data_logger::LogLevel::INFO);
config.setTextBufferSize(128 * 1024); // 128 KB

// Binary trace configuration
config.setTraceLogPath("/var/log/trace.bin");
config.setTraceBufferSize(1024 * 1024); // 1 MB

// DXR configuration
config.setDxrEnabled(true);
config.setDxrTextGroupId(100);
config.setDxrBinaryGroupId(101);

// Synchronization
config.setThreadSafe(true);
config.setProcessSafe(true);  // Enable for multi-process
config.setLockFilePath("/var/lock/myapp_logger.lock");

// Auto-flush on errors
config.setFlushOnLevel(data_logger::LogLevel::ERROR);

// Apply configuration
data_logger::DataLogger::configure(config);
```

## API Reference

### Log Levels

- `DEBUG` - Detailed diagnostic information
- `INFO` - General informational messages
- `WARNING` - Warning messages for potentially problematic situations
- `ERROR` - Error messages for failures
- `CRITICAL` - Critical failures requiring immediate attention

### TextLogger

```cpp
class TextLogger {
    void logDebug(const std::string& message);
    void logInfo(const std::string& message);
    void logWarning(const std::string& message);
    void logError(const std::string& message);
    void logCritical(const std::string& message);
    void log(LogLevel level, const std::string& message);
    
    void setMinimumLevel(LogLevel level);
    LogLevel getMinimumLevel() const;
    
    void flush();
    void close();
    bool isOpen() const;
};
```

### TraceLogger

```cpp
class TraceLogger {
    void logTrace(uint32_t messageId, const void* data, size_t size);
    
    template<typename T>
    void logTrace(uint32_t messageId, const T& data);
    
    void flush();
    void close();
    bool isOpen() const;
};
```

### DxrLogger (Stub)

```cpp
class DxrLogger {
    void initialize();
    void logMessage(const std::string& message);
    void logMessage(uint32_t messageId, const void* data, size_t size);
    void shutdown();
    bool isConnected() const;  // Always returns false (stub)
};
```

## Text Log Format

Format: `[YYYY-MM-DD HH:MM:SS.nnnnnnnnn] [LEVEL] message`

Example:
```
[2026-07-23 14:32:45.123456789] [INFO] Application started
[2026-07-23 14:32:46.234567890] [WARNING] Resource usage at 85%
[2026-07-23 14:32:47.345678901] [ERROR] Connection timeout
```

## Binary Trace Format

### File Header (32 bytes)
- Magic: 0x54524143 ('TRAC' in ASCII)
- Version Major: 1
- Version Minor: 0
- Creation Timestamp: nanoseconds since Unix epoch
- Entry Count: 0 = unknown
- Reserved: 8 bytes (zero)

### Trace Entry (variable size)
- Timestamp: 8 bytes (nanoseconds since Unix epoch)
- Message ID: 4 bytes (user-defined)
- Payload Size: 4 bytes
- Payload: N bytes (binary data)

All values in little-endian byte order.

## Thread Safety & Multi-Process Support

### Thread Safety (Default: Enabled)

```cpp
LogConfig config;
config.setThreadSafe(true);  // Default
```

Uses `std::mutex` for thread synchronization. Safe for concurrent logging from multiple threads in the same process.

### Process Safety (Default: Disabled)

```cpp
LogConfig config;
config.setProcessSafe(true);
config.setLockFilePath("/var/lock/myapp.lock");  // Optional, auto-generated if not set
```

Uses file-based locking (`fcntl`) for inter-process synchronization. Enables safe logging from multiple processes to the same log file.

**Features:**
- Works over NFS (network filesystems)
- Automatically released when process exits
- No cleanup required (unlike semaphores)
- Lock file is auto-generated as `<logfile>.lock` if not specified

**Note**: Process-safe mode has higher overhead. Only enable if multiple processes write to the same log file.

## Performance

### Buffering Strategy

DataLogger uses in-memory buffering to minimize system calls:

- **Text logs**: 64 KB buffer (default, configurable)
- **Binary traces**: 1 MB buffer (default, configurable)

Buffers are flushed:
- When buffer is full
- On explicit `flush()` call
- When logging at or above `FlushOnLevel` (default: ERROR)
- On logger destruction

### Expected Performance

- **Text logging**: >= 100,000 messages/second
- **Binary trace logging**: >= 100 MB/second

(Actual performance depends on hardware, buffer configuration, and synchronization settings)

## Building & Installing

### Building the Library

```bash
cd CommonModules
mkdir -p build && cd build
cmake ..
make
```

### Running Tests

```bash
ctest --output-on-failure
```

Or run specific tests:
```bash
./data_logger_user_test
```

### Installing

```bash
make install
```

Installs to `CommonModules/lib/` and `CommonModules/include/`.

## Using in Your Project

### CMake

```cmake
find_package(data_logger REQUIRED)
target_link_libraries(your_target PRIVATE CommonModules::data_logger)
```

### Manual Linking

```bash
g++ -std=c++11 myapp.cpp -ldata_logger -pthread -o myapp
```

## Error Handling

DataLogger uses exception-based error handling:

- `std::runtime_error` - File I/O errors, write failures
- `std::invalid_argument` - Invalid configuration
- `std::system_error` - Semaphore/system errors

Example:
```cpp
try {
    auto logger = data_logger::DataLogger::createTextLogger("/invalid/path/log.txt");
} catch (const std::runtime_error& e) {
    std::cerr << "Failed to create logger: " << e.what() << std::endl;
}
```

## Examples

### Structured Logging with Context

```cpp
void processRequest(int requestId, const std::string& user) {
    auto logger = data_logger::DataLogger::createTextLogger("requests.log");
    
    logger->logInfo("Processing request " + std::to_string(requestId) + 
                    " for user " + user);
    
    try {
        // ... process request ...
        logger->logInfo("Request " + std::to_string(requestId) + " completed");
    } catch (const std::exception& e) {
        logger->logError("Request " + std::to_string(requestId) + 
                        " failed: " + e.what());
    }
}
```

### High-Performance Trace Logging

```cpp
struct NetworkPacket {
    uint64_t timestamp;
    uint32_t sourceIp;
    uint32_t destIp;
    uint16_t sourcePort;
    uint16_t destPort;
    uint32_t payloadSize;
};

void capturePacket(const NetworkPacket& packet) {
    static auto tracer = data_logger::DataLogger::createTraceLogger("network.bin");
    tracer->logTrace(5001, packet);  // Zero-copy using template
}
```

### Multi-Logger Application

```cpp
class Application {
    data_logger::LogConfig config;
    std::unique_ptr<data_logger::TextLogger> appLog;
    std::unique_ptr<data_logger::TextLogger> auditLog;
    std::unique_ptr<data_logger::TraceLogger> perfTrace;
    
public:
    Application() {
        config.setThreadSafe(true);
        
        appLog = data_logger::DataLogger::createTextLogger("app.log");
        
        config.setMinimumLevel(data_logger::LogLevel::INFO);
        auditLog = data_logger::DataLogger::createTextLogger(config);
        
        perfTrace = data_logger::DataLogger::createTraceLogger("perf.bin");
    }
    
    void run() {
        appLog->logInfo("Application starting");
        auditLog->logInfo("User admin logged in");
        
        uint64_t startTime = getCurrentTime();
        // ... do work ...
        uint64_t endTime = getCurrentTime();
        
        perfTrace->logTrace(6001, startTime);
        perfTrace->logTrace(6002, endTime);
    }
};
```

## DXR Integration

The DXR logger is currently a stub implementation. All methods are callable but perform no operations:

```cpp
auto dxr = data_logger::DataLogger::createDxrLogger(config);
dxr->initialize();               // No-op
dxr->logMessage("Test");         // No-op
dxr->shutdown();                 // No-op
dxr->isConnected();              // Returns false
```

**TODO**: Implement actual DXR library integration when available.

## Limitations & Future Enhancements

### Current Limitations
- No automatic log rotation (manual rotation required)
- No asynchronous/background logging (all writes are synchronous)
- No compression support
- No network logging (syslog, etc.)
- DXR integration not implemented

### Planned Enhancements
- Optional log rotation by size/time
- Async logging with background thread
- Optional gzip compression
- Syslog/UDP logging support
- Binary trace file reader utility
- Performance profiling and optimization

## Troubleshooting

### Permission Denied
Ensure the process has write permissions to the log directory and lock file location:
```bash
chmod 755 /var/log/myapp
chmod 666 /var/lock/myapp.lock  # If using custom lock file path
```

### Stale Lock Files
Lock files are automatically released when a process exits. If you see stale `.lock` files, they can be safely removed:
```bash
rm /tmp/myapp.log.lock
```

### NFS Locking Issues
If using NFS-mounted log directories:
- Ensure NFS server supports file locking (`lockd` daemon running)
- Mount with `lock` option (not `nolock`)
- Test locking with: `flock /path/to/nfs/file.lock -c "echo locked"`

### Performance Issues
- Increase buffer sizes for high-throughput scenarios
- Disable process-safe mode if not needed
- Consider async logging for critical paths (future enhancement)

## License

[Your license here]

## Contributing

[Contributing guidelines here]

## Support

For issues or questions, please [contact info or issue tracker]
