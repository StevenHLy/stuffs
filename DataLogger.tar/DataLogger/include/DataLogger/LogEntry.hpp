/**
 * @file LogEntry.hpp
 * @brief Log entry data structures for text and binary logging
 */

#pragma once

#include "Export.hpp"
#include "LogLevel.hpp"
#include <cstddef>
#include <cstdint>
#include <string>

namespace data_logger {

/**
 * @brief A text log entry with timestamp, level, and message
 */
struct DATALOGGER_API TextLogEntry {
    std::uint64_t timestamp_ns; ///< Nanoseconds since Unix epoch
    LogLevel level;              ///< Severity level
    std::string message;         ///< Log message content
    
    /**
     * @brief Construct a text log entry with current timestamp
     * @param lvl Severity level
     * @param msg Log message
     */
    TextLogEntry(LogLevel lvl, const std::string& msg);
    
    /**
     * @brief Construct a text log entry with explicit timestamp
     * @param ts Timestamp in nanoseconds since Unix epoch
     * @param lvl Severity level
     * @param msg Log message
     */
    TextLogEntry(std::uint64_t ts, LogLevel lvl, const std::string& msg);
};

/**
 * @brief A binary trace log entry with timestamp, message ID, and payload
 */
struct DATALOGGER_API TraceLogEntry {
    std::uint64_t timestamp_ns;  ///< Nanoseconds since Unix epoch
    std::uint32_t message_id;    ///< User-defined message type identifier
    std::uint32_t payload_size;  ///< Size of payload in bytes
    const void* payload;          ///< Pointer to binary data
    
    /**
     * @brief Construct a trace log entry with current timestamp
     * @param id Message type identifier
     * @param data Pointer to binary payload
     * @param size Size of payload in bytes
     */
    TraceLogEntry(std::uint32_t id, const void* data, std::size_t size);
    
    /**
     * @brief Construct a trace log entry with explicit timestamp
     * @param ts Timestamp in nanoseconds since Unix epoch
     * @param id Message type identifier
     * @param data Pointer to binary payload
     * @param size Size of payload in bytes
     */
    TraceLogEntry(std::uint64_t ts, std::uint32_t id, const void* data, std::size_t size);
};

} // namespace data_logger
