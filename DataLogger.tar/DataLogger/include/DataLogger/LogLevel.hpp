/**
 * @file LogLevel.hpp
 * @brief Log severity level definitions and utilities
 */

#pragma once

#include "Export.hpp"
#include <cstdint>
#include <string>

namespace data_logger {

/**
 * @brief Severity levels for text logging
 * 
 * Ordered from lowest to highest severity.
 */
enum class LogLevel : std::uint8_t {
    DEBUG = 0,      ///< Detailed diagnostic information
    INFO = 1,       ///< General informational messages
    WARNING = 2,    ///< Warning messages for potentially problematic situations
    ERROR = 3,      ///< Error messages for failures
    CRITICAL = 4    ///< Critical failures requiring immediate attention
};

/**
 * @brief Convert a LogLevel to its string representation
 * @param level The log level to convert
 * @return String representation (e.g., "DEBUG", "INFO", etc.)
 */
DATALOGGER_API const char* toString(LogLevel level);

/**
 * @brief Convert a string to a LogLevel
 * @param levelStr String representation of level (case-insensitive)
 * @return The corresponding LogLevel
 * @throws std::invalid_argument if the string is not a valid level
 */
DATALOGGER_API LogLevel fromString(const std::string& levelStr);

} // namespace data_logger
