/**
 * @file LogConfig.hpp
 * @brief Configuration options for DataLogger components
 */

#pragma once

#include "Export.hpp"
#include "LogLevel.hpp"
#include <cstddef>
#include <cstdint>
#include <string>

namespace data_logger {

/**
 * @brief Configuration class for logging behavior
 * 
 * Provides a centralized way to configure text logging, binary trace logging,
 * and DXR integration options.
 */
class DATALOGGER_API LogConfig {
public:
    /**
     * @brief Construct a LogConfig with default settings
     */
    LogConfig();
    
    // Text logging configuration
    
    /**
     * @brief Set the file path for text logs
     * @param path Path to text log file
     */
    void setTextLogPath(const std::string& path);
    
    /**
     * @brief Set the minimum log level for text logging
     * @param level Minimum severity level to log (lower levels will be filtered)
     */
    void setMinimumLevel(LogLevel level);
    
    /**
     * @brief Set the text log buffer size
     * @param bytes Buffer size in bytes (default: 65536 = 64 KB)
     */
    void setTextBufferSize(std::size_t bytes);
    
    // Binary trace configuration
    
    /**
     * @brief Set the file path for binary trace logs
     * @param path Path to trace log file
     */
    void setTraceLogPath(const std::string& path);
    
    /**
     * @brief Set the trace log buffer size
     * @param bytes Buffer size in bytes (default: 1048576 = 1 MB)
     */
    void setTraceBufferSize(std::size_t bytes);
    
    // DXR configuration
    
    /**
     * @brief Enable or disable DXR logging
     * @param enabled True to enable DXR logging
     */
    void setDxrEnabled(bool enabled);
    
    /**
     * @brief Set the DXR endpoint configuration
     * @param endpoint DXR connection endpoint (format: "hostname:port")
     */
    void setDxrEndpoint(const std::string& endpoint);
    
    /**
     * @brief Set the DXR configuration file path
     * @param filepath Path to DXR configuration file (optional)
     * @note If not set, minimal configuration will be used
     */
    void setDxrConfigFile(const std::string& filepath);
    
    /**
     * @brief Set the Data Recording Group ID for text logging
     * @param group_id DRG ID for text messages (default: 100)
     */
    void setDxrTextGroupId(unsigned int group_id);
    
    /**
     * @brief Set the Data Recording Group ID for binary logging
     * @param group_id DRG ID for binary messages (default: 101)
     */
    void setDxrBinaryGroupId(unsigned int group_id);
    
    /**
     * @brief Set the application ID for DXR
     * @param app_id Application identifier (default: getpid())
     */
    void setDxrApplicationId(unsigned int app_id);
    
    /**
     * @brief Set the text buffer pool size
     * @param num_buffers Number of buffers in text pool (default: 10)
     */
    void setDxrTextBufferPoolSize(unsigned int num_buffers);
    
    /**
     * @brief Set the binary buffer pool size
     * @param num_buffers Number of buffers in binary pool (default: 10)
     */
    void setDxrBinaryBufferPoolSize(unsigned int num_buffers);
    
    /**
     * @brief Set the text buffer size
     * @param buffer_bytes Size of each text buffer in bytes (default: 4096)
     */
    void setDxrTextBufferSize(unsigned int buffer_bytes);
    
    /**
     * @brief Set the binary buffer size
     * @param buffer_bytes Size of each binary buffer in bytes (default: 8192)
     */
    void setDxrBinaryBufferSize(unsigned int buffer_bytes);
    
    /**
     * @brief Set the base extraction point number for text messages
     * @param ep_base Base EP number (text messages use ep_base + offset)
     */
    void setDxrTextEpBase(unsigned int ep_base);
    
    /**
     * @brief Set the base extraction point number for binary messages
     * @param ep_base Base EP number (binary messages use ep_base + message_id)
     */
    void setDxrBinaryEpBase(unsigned int ep_base);
    
    // Flush behavior
    
    /**
     * @brief Set automatic flush interval
     * @param milliseconds Flush interval in milliseconds (0 = disabled)
     */
    void setAutoFlushInterval(std::uint32_t milliseconds);
    
    /**
     * @brief Set log level that triggers automatic flush
     * @param level Flush when logging at or above this level (ERROR recommended)
     */
    void setFlushOnLevel(LogLevel level);
    
    // Synchronization
    
    /**
     * @brief Enable or disable thread-safe operations
     * @param enabled True to enable mutex protection (default: true)
     */
    void setThreadSafe(bool enabled);
    
    /**
     * @brief Enable or disable process-safe operations
     * @param enabled True to enable inter-process file locking (default: false)
     */
    void setProcessSafe(bool enabled);
    
    /**
     * @brief Set the lock file path for inter-process synchronization
     * @param path Path to lock file (e.g., "/var/lock/datalogger_myapp.lock")
     * @note If not set, will be auto-generated from log file path
     */
    void setLockFilePath(const std::string& path);
    
    // Getters
    
    const std::string& getTextLogPath() const { return text_log_path_; }
    LogLevel getMinimumLevel() const { return minimum_level_; }
    std::size_t getTextBufferSize() const { return text_buffer_size_; }
    
    const std::string& getTraceLogPath() const { return trace_log_path_; }
    std::size_t getTraceBufferSize() const { return trace_buffer_size_; }
    
    bool getDxrEnabled() const { return dxr_enabled_; }
    const std::string& getDxrEndpoint() const { return dxr_endpoint_; }
    const std::string& getDxrConfigFile() const { return dxr_config_file_; }
    unsigned int getDxrTextGroupId() const { return dxr_text_group_id_; }
    unsigned int getDxrBinaryGroupId() const { return dxr_binary_group_id_; }
    unsigned int getDxrApplicationId() const { return dxr_application_id_; }
    unsigned int getDxrTextBufferPoolSize() const { return dxr_text_buffer_pool_size_; }
    unsigned int getDxrBinaryBufferPoolSize() const { return dxr_binary_buffer_pool_size_; }
    unsigned int getDxrTextBufferSize() const { return dxr_text_buffer_size_; }
    unsigned int getDxrBinaryBufferSize() const { return dxr_binary_buffer_size_; }
    unsigned int getDxrTextEpBase() const { return dxr_text_ep_base_; }
    unsigned int getDxrBinaryEpBase() const { return dxr_binary_ep_base_; }
    
    std::uint32_t getAutoFlushInterval() const { return auto_flush_ms_; }
    LogLevel getFlushOnLevel() const { return flush_on_level_; }
    
    bool getThreadSafe() const { return thread_safe_; }
    bool getProcessSafe() const { return process_safe_; }
    const std::string& getLockFilePath() const { return lock_file_path_; }
    
private:
    std::string text_log_path_;
    std::string trace_log_path_;
    LogLevel minimum_level_;
    std::size_t text_buffer_size_;
    std::size_t trace_buffer_size_;
    
    // DXR settings
    bool dxr_enabled_;
    std::string dxr_endpoint_;
    std::string dxr_config_file_;
    unsigned int dxr_text_group_id_;
    unsigned int dxr_binary_group_id_;
    unsigned int dxr_application_id_;
    unsigned int dxr_text_buffer_pool_size_;
    unsigned int dxr_binary_buffer_pool_size_;
    unsigned int dxr_text_buffer_size_;
    unsigned int dxr_binary_buffer_size_;
    unsigned int dxr_text_ep_base_;
    unsigned int dxr_binary_ep_base_;
    
    std::uint32_t auto_flush_ms_;
    LogLevel flush_on_level_;
    bool thread_safe_;
    bool process_safe_;
    std::string lock_file_path_;
};

} // namespace data_logger
