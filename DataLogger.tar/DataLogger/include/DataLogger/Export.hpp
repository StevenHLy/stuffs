/**
 * @file Export.hpp
 * @brief DLL export/import macros for cross-platform symbol visibility
 */

#pragma once

#if defined(_WIN32) || defined(_WIN64)
    #ifdef DATALOGGER_BUILD
        #define DATALOGGER_API __declspec(dllexport)
    #else
        #define DATALOGGER_API __declspec(dllimport)
    #endif
#else
    #ifdef DATALOGGER_BUILD
        #define DATALOGGER_API __attribute__((visibility("default")))
    #else
        #define DATALOGGER_API
    #endif
#endif
