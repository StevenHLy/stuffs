/**
 * @file TraceLogger.hpp
 * @brief Public API for binary trace logging
 */

#pragma once

#include "Export.hpp"
#include "LogConfig.hpp"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <type_traits>

namespace data_logger {

/**
 * @brief Binary trace logger for high-performance message logging
 * 
 * Provides thread-safe and optionally process-safe logging of binary messages
 * with timestamps, message IDs, and raw payload data.
 */
class DATALOGGER_API TraceLogger {
public:
    /**
     * @brief Construct a TraceLogger with default configuration
     * @param filePath Path to the trace log file
     * @throws std::runtime_error if file cannot be opened
     */
    explicit TraceLogger(const std::string& filePath);
    
    /**
     * @brief Construct a TraceLogger with full configuration
     * @param config Configuration options
     * @throws std::runtime_error if file cannot be opened or config is invalid
     */
    explicit TraceLogger(const LogConfig& config);
    
    /**
     * @brief Destructor - flushes and closes log file
     */
    ~TraceLogger();
    
    // Non-copyable, movable
    TraceLogger(const TraceLogger&) = delete;
    TraceLogger& operator=(const TraceLogger&) = delete;
    TraceLogger(TraceLogger&&) noexcept;
    TraceLogger& operator=(TraceLogger&&) noexcept;
    
    /**
     * @brief Log a binary trace message
     * @param messageId User-defined message type identifier
     * @param data Pointer to binary payload
     * @param size Size of payload in bytes
     */
    void logTrace(std::uint32_t messageId, const void* data, std::size_t size);
    
    /**
     * @brief Log a binary trace message (template convenience for POD types)
     * @tparam T Type of data (must be trivially copyable)
     * @param messageId User-defined message type identifier
     * @param data Reference to data object
     */
    template<typename T>
    void logTrace(std::uint32_t messageId, const T& data) {
        static_assert(std::is_trivially_copyable<T>::value,
                      "T must be trivially copyable for binary logging");
        logTrace(messageId, &data, sizeof(T));
    }
    
    /**
     * @brief Flush buffered trace entries to disk
     */
    void flush();
    
    /**
     * @brief Close the log file (also flushes)
     */
    void close();
    
    /**
     * @brief Check if the logger is open and operational
     * @return True if logger is open
     */
    bool isOpen() const;
    
private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace data_logger
