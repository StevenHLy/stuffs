/**
 * @file DataLogger.hpp
 * @brief Main public API header with static convenience methods
 */

#pragma once

#include "Export.hpp"
#include "DxrLogger.hpp"
#include "LogConfig.hpp"
#include "LogLevel.hpp"
#include "TextLogger.hpp"
#include "TraceLogger.hpp"
#include <cstddef>
#include <cstdint>
#include <memory>
#include <string>

namespace data_logger {

/**
 * @brief Static convenience facade for DataLogger functionality
 * 
 * Provides static methods for simple logging use cases while also
 * offering factory methods for instance-based usage when more
 * control is needed.
 */
class DATALOGGER_API DataLogger {
public:
    // Static convenience methods for text logging
    
    /**
     * @brief Log an info message using default logger
     * @param message Log message content
     */
    static void logInfo(const std::string& message);
    
    /**
     * @brief Log a warning message using default logger
     * @param message Log message content
     */
    static void logWarning(const std::string& message);
    
    /**
     * @brief Log an error message using default logger
     * @param message Log message content
     */
    static void logError(const std::string& message);
    
    /**
     * @brief Log a debug message using default logger
     * @param message Log message content
     */
    static void logDebug(const std::string& message);
    
    /**
     * @brief Log a critical message using default logger
     * @param message Log message content
     */
    static void logCritical(const std::string& message);
    
    // Static convenience method for binary trace logging
    
    /**
     * @brief Log a binary trace message using default logger
     * @param messageId Message type identifier
     * @param data Pointer to binary payload
     * @param size Size of payload in bytes
     */
    static void logTrace(std::uint32_t messageId, const void* data, std::size_t size);
    
    // Configuration and control
    
    /**
     * @brief Configure the default loggers
     * @param config Configuration options
     */
    static void configure(const LogConfig& config);
    
    /**
     * @brief Flush all default loggers
     */
    static void flush();
    
    /**
     * @brief Shutdown and close all default loggers
     */
    static void shutdown();
    
    // Factory methods for instance-based usage
    
    /**
     * @brief Create a new TextLogger instance
     * @param filePath Path to text log file
     * @return Unique pointer to TextLogger
     */
    static std::unique_ptr<TextLogger> createTextLogger(const std::string& filePath);
    
    /**
     * @brief Create a new TextLogger instance with configuration
     * @param config Configuration options
     * @return Unique pointer to TextLogger
     */
    static std::unique_ptr<TextLogger> createTextLogger(const LogConfig& config);
    
    /**
     * @brief Create a new TraceLogger instance
     * @param filePath Path to trace log file
     * @return Unique pointer to TraceLogger
     */
    static std::unique_ptr<TraceLogger> createTraceLogger(const std::string& filePath);
    
    /**
     * @brief Create a new TraceLogger instance with configuration
     * @param config Configuration options
     * @return Unique pointer to TraceLogger
     */
    static std::unique_ptr<TraceLogger> createTraceLogger(const LogConfig& config);
    
    /**
     * @brief Create a new DxrLogger instance
     * @param config Configuration options
     * @return Unique pointer to DxrLogger
     */
    static std::unique_ptr<DxrLogger> createDxrLogger(const LogConfig& config);
    
private:
    // Static-only class
    DataLogger() = delete;
    ~DataLogger() = delete;
    DataLogger(const DataLogger&) = delete;
    DataLogger& operator=(const DataLogger&) = delete;
};

} // namespace data_logger
