/**
 * @file TextLogger.hpp
 * @brief Public API for textual logging
 */

#pragma once

#include "Export.hpp"
#include "LogConfig.hpp"
#include "LogLevel.hpp"
#include <memory>
#include <string>

namespace data_logger {

/**
 * @brief Text logger for structured log messages
 * 
 * Provides thread-safe and optionally process-safe logging of text messages
 * with timestamps, severity levels, and configurable buffering.
 */
class DATALOGGER_API TextLogger {
public:
    /**
     * @brief Construct a TextLogger with default configuration
     * @param filePath Path to the log file
     * @throws std::runtime_error if file cannot be opened
     */
    explicit TextLogger(const std::string& filePath);
    
    /**
     * @brief Construct a TextLogger with full configuration
     * @param config Configuration options
     * @throws std::runtime_error if file cannot be opened or config is invalid
     */
    explicit TextLogger(const LogConfig& config);
    
    /**
     * @brief Destructor - flushes and closes log file
     */
    ~TextLogger();
    
    // Non-copyable, movable
    TextLogger(const TextLogger&) = delete;
    TextLogger& operator=(const TextLogger&) = delete;
    TextLogger(TextLogger&&) noexcept;
    TextLogger& operator=(TextLogger&&) noexcept;
    
    /**
     * @brief Log a message at specified level
     * @param level Severity level
     * @param message Log message content
     */
    void log(LogLevel level, const std::string& message);
    
    /**
     * @brief Log a debug message
     * @param message Log message content
     */
    void logDebug(const std::string& message);
    
    /**
     * @brief Log an info message
     * @param message Log message content
     */
    void logInfo(const std::string& message);
    
    /**
     * @brief Log a warning message
     * @param message Log message content
     */
    void logWarning(const std::string& message);
    
    /**
     * @brief Log an error message
     * @param message Log message content
     */
    void logError(const std::string& message);
    
    /**
     * @brief Log a critical message
     * @param message Log message content
     */
    void logCritical(const std::string& message);
    
    /**
     * @brief Set the minimum log level (filter lower levels)
     * @param level Minimum severity level to log
     */
    void setMinimumLevel(LogLevel level);
    
    /**
     * @brief Get the current minimum log level
     * @return Current minimum level
     */
    LogLevel getMinimumLevel() const;
    
    /**
     * @brief Flush buffered log entries to disk
     */
    void flush();
    
    /**
     * @brief Close the log file (also flushes)
     */
    void close();
    
    /**
     * @brief Check if the logger is open and operational
     * @return True if logger is open
     */
    bool isOpen() const;
    
private:
    class Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace data_logger
