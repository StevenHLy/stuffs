/**
 * @file DataLoggerBenchmark.cpp
 * @brief Performance benchmarks for DataLogger
 */

#include <benchmark/benchmark.h>
#include "DataLogger/TextLogger.hpp"
#include "DataLogger/TraceLogger.hpp"
#include "DataLogger/LogConfig.hpp"
#include <cstdint>
#include <string>

using namespace data_logger;

// Test data structures
struct SensorData {
    std::uint64_t timestamp;
    double temperature;
    double pressure;
    double humidity;
    std::uint32_t sensor_id;
};

// ============================================================================
// Text Logging Benchmarks
// ============================================================================

/**
 * @brief Benchmark text logging with INFO level
 */
static void BM_TextLogger_Info(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_info.log";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(logPath));
    const std::string message = "Benchmark test message with some content";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    // Report throughput
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * message.size());
}
BENCHMARK(BM_TextLogger_Info);

/**
 * @brief Benchmark text logging with different log levels
 */
static void BM_TextLogger_AllLevels(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_levels.log";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(logPath));
    const std::string message = "Test message";
    
    int level = 0;
    for (auto _ : state) {
        switch (level % 5) {
            case 0: logger->logDebug(message); break;
            case 1: logger->logInfo(message); break;
            case 2: logger->logWarning(message); break;
            case 3: logger->logError(message); break;
            case 4: logger->logCritical(message); break;
        }
        level++;
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
}
BENCHMARK(BM_TextLogger_AllLevels);

/**
 * @brief Benchmark text logging with level filtering
 */
static void BM_TextLogger_Filtering(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_filter.log";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(logPath));
    logger->setMinimumLevel(LogLevel::ERROR); // Filter out lower levels
    
    for (auto _ : state) {
        logger->logDebug("This will be filtered");
        logger->logInfo("This will also be filtered");
        logger->logError("This will be logged");
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations() * 3);
}
BENCHMARK(BM_TextLogger_Filtering);

/**
 * @brief Benchmark text logging with large buffer
 */
static void BM_TextLogger_LargeBuffer(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_large.log";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTextLogPath(logPath);
    config.setTextBufferSize(1024 * 1024); // 1 MB buffer
    config.setThreadSafe(false); // Disable for max performance
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(config));
    const std::string message = "Performance test message";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
}
BENCHMARK(BM_TextLogger_LargeBuffer);

/**
 * @brief Benchmark text logging with thread safety enabled
 */
static void BM_TextLogger_ThreadSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_threadsafe.log";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTextLogPath(logPath);
    config.setThreadSafe(true);
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(config));
    const std::string message = "Thread-safe logging";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
}
BENCHMARK(BM_TextLogger_ThreadSafe);

/**
 * @brief Benchmark text logging with process safety (file locking)
 */
static void BM_TextLogger_ProcessSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_processsafe.log";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTextLogPath(logPath);
    config.setThreadSafe(false);  // Disable thread safety to isolate process lock overhead
    config.setProcessSafe(true);  // Enable file locking
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(config));
    const std::string message = "Process-safe logging";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    std::remove((logPath + ".lock").c_str());
    
    state.SetItemsProcessed(state.iterations());
}
BENCHMARK(BM_TextLogger_ProcessSafe);

/**
 * @brief Benchmark text logging with both thread and process safety
 */
static void BM_TextLogger_ThreadAndProcessSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_both.log";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTextLogPath(logPath);
    config.setThreadSafe(true);
    config.setProcessSafe(true);
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(config));
    const std::string message = "Thread and process-safe logging";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    std::remove((logPath + ".lock").c_str());
    
    state.SetItemsProcessed(state.iterations());
}
BENCHMARK(BM_TextLogger_ThreadAndProcessSafe);

// ============================================================================
// Binary Trace Logging Benchmarks
// ============================================================================

/**
 * @brief Benchmark binary trace logging with small payload
 */
static void BM_TraceLogger_SmallPayload(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_small.bin";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(logPath));
    std::uint32_t data = 0xDEADBEEF;
    std::uint32_t msgId = 1000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_SmallPayload);

/**
 * @brief Benchmark binary trace logging with medium struct
 */
static void BM_TraceLogger_MediumPayload(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_medium.bin";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(logPath));
    SensorData data = {1234567890, 25.5, 1013.25, 65.0, 42};
    std::uint32_t msgId = 2000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_MediumPayload);

/**
 * @brief Benchmark binary trace logging with large payload
 */
static void BM_TraceLogger_LargePayload(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_large.bin";
    std::remove(logPath.c_str());
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(logPath));
    
    // Simulate large network packet or data buffer
    char largeData[4096];
    for (int i = 0; i < 4096; i++) {
        largeData[i] = static_cast<char>(i % 256);
    }
    
    std::uint32_t msgId = 3000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, largeData, sizeof(largeData));
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(largeData));
}
BENCHMARK(BM_TraceLogger_LargePayload);

/**
 * @brief Benchmark binary trace logging with large buffer
 */
static void BM_TraceLogger_LargeBuffer(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_buffer.bin";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTraceLogPath(logPath);
    config.setTraceBufferSize(8 * 1024 * 1024); // 8 MB buffer
    config.setThreadSafe(false); // Disable for max performance
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(config));
    std::uint64_t data = 0x0123456789ABCDEF;
    std::uint32_t msgId = 4000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_LargeBuffer);

/**
 * @brief Benchmark binary trace logging with thread safety
 */
static void BM_TraceLogger_ThreadSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_threadsafe.bin";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTraceLogPath(logPath);
    config.setThreadSafe(true);
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(config));
    std::uint64_t data = 0xCAFEBABEDEADBEEF;
    std::uint32_t msgId = 5000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_ThreadSafe);

/**
 * @brief Benchmark binary trace logging with process safety (file locking)
 */
static void BM_TraceLogger_ProcessSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_processsafe.bin";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTraceLogPath(logPath);
    config.setThreadSafe(false);  // Disable thread safety to isolate process lock overhead
    config.setProcessSafe(true);  // Enable file locking
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(config));
    std::uint64_t data = 0xCAFEBABEDEADBEEF;
    std::uint32_t msgId = 6000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    std::remove((logPath + ".lock").c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_ProcessSafe);

/**
 * @brief Benchmark binary trace logging with both thread and process safety
 */
static void BM_TraceLogger_ThreadAndProcessSafe(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_both.bin";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTraceLogPath(logPath);
    config.setThreadSafe(true);
    config.setProcessSafe(true);
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(config));
    std::uint64_t data = 0xCAFEBABEDEADBEEF;
    std::uint32_t msgId = 7000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, data);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    std::remove((logPath + ".lock").c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(data));
}
BENCHMARK(BM_TraceLogger_ThreadAndProcessSafe);

// ============================================================================
// Mixed Workload Benchmarks
// ============================================================================

/**
 * @brief Benchmark mixed text and binary logging
 */
static void BM_MixedLogging(benchmark::State& state) {
    const std::string textPath = "/tmp/bench_mixed_text.log";
    const std::string tracePath = "/tmp/bench_mixed_trace.bin";
    std::remove(textPath.c_str());
    std::remove(tracePath.c_str());
    
    auto textLogger = std::unique_ptr<TextLogger>(new TextLogger(textPath));
    auto traceLogger = std::unique_ptr<TraceLogger>(new TraceLogger(tracePath));
    
    SensorData sensorData = {1234567890, 22.5, 1015.0, 55.0, 1};
    std::uint32_t msgId = 6000;
    
    for (auto _ : state) {
        textLogger->logInfo("Sensor reading captured");
        traceLogger->logTrace(msgId++, sensorData);
    }
    
    textLogger->flush();
    traceLogger->flush();
    textLogger->close();
    traceLogger->close();
    
    std::remove(textPath.c_str());
    std::remove(tracePath.c_str());
    
    state.SetItemsProcessed(state.iterations() * 2);
}
BENCHMARK(BM_MixedLogging);

// ============================================================================
// Throughput Benchmarks (measure msgs/sec and MB/sec)
// ============================================================================

/**
 * @brief Text logging throughput test
 */
static void BM_TextThroughput(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_text_throughput.log";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTextLogPath(logPath);
    config.setTextBufferSize(2 * 1024 * 1024); // 2 MB buffer
    config.setThreadSafe(false);
    
    auto logger = std::unique_ptr<TextLogger>(new TextLogger(config));
    const std::string message = "High throughput logging test message";
    
    for (auto _ : state) {
        logger->logInfo(message);
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetLabel("messages/sec");
}
BENCHMARK(BM_TextThroughput);

/**
 * @brief Binary trace throughput test
 */
static void BM_TraceThroughput(benchmark::State& state) {
    const std::string logPath = "/tmp/bench_trace_throughput.bin";
    std::remove(logPath.c_str());
    
    LogConfig config;
    config.setTraceLogPath(logPath);
    config.setTraceBufferSize(4 * 1024 * 1024); // 4 MB buffer
    config.setThreadSafe(false);
    
    auto logger = std::unique_ptr<TraceLogger>(new TraceLogger(config));
    
    // 1KB data block
    char dataBlock[1024];
    for (int i = 0; i < 1024; i++) {
        dataBlock[i] = static_cast<char>(i % 256);
    }
    
    std::uint32_t msgId = 7000;
    
    for (auto _ : state) {
        logger->logTrace(msgId++, dataBlock, sizeof(dataBlock));
    }
    
    logger->flush();
    logger->close();
    std::remove(logPath.c_str());
    
    state.SetItemsProcessed(state.iterations());
    state.SetBytesProcessed(state.iterations() * sizeof(dataBlock));
    state.SetLabel("MB/sec");
}
BENCHMARK(BM_TraceThroughput);

BENCHMARK_MAIN();
