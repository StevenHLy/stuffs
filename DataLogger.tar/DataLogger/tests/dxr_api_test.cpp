/**
 * @file dxr_api_test.cpp
 * @brief Minimal test program to verify DXR API is accessible
 * 
 * This program tests that we can:
 * 1. Include dxr.h
 * 2. Call basic DXR API functions
 * 3. Link against DXR libraries successfully
 */

#include <iostream>
#include <cstring>

#ifdef HAVE_DXR
#include <dxr.h>
#endif

int main() {
    std::cout << "=== DXR API Test ===" << std::endl;
    
#ifdef HAVE_DXR
    std::cout << "DXR is available!" << std::endl;
    
    // Test 1: Check if we can call DXR_CountAttachments
    const char* test_pool = "test_pool";
    int count = 0;
    int result = DXR_CountAttachments(test_pool, &count);
    
    std::cout << "DXR_CountAttachments returned: " << result << std::endl;
    
    // We expect DXR_NOPOOL or DXR_NOTRDY since daemon is likely not running
    // But the important thing is the function is callable
    
    if (result == DXR_SUCCESS) {
        std::cout << "  Pool exists with " << count << " attachments" << std::endl;
    } else if (result == DXR_NOPOOL) {
        std::cout << "  Pool doesn't exist (expected)" << std::endl;
    } else if (result == DXR_NOTRDY) {
        std::cout << "  DXR daemon not ready (expected if not running)" << std::endl;
    } else {
        std::cout << "  Other error code: " << result << std::endl;
    }
    
    // Test 2: Try to create a buffer pool (will likely fail without daemon)
    std::cout << "\nAttempting to create buffer pool..." << std::endl;
    result = DXR_CreateBufferPool(
        "test_datalogger_pool",  // pool name
        12345,                    // local_recording_client_id
        1024,                     // local_buffer_size
        5,                        // number_of_local_buffers
        DXR_NOTIMEOUT,           // local_buffer_timeout (no timeout)
        12345,                    // remote_recording_client_id
        1024,                     // remote_buffer_size
        5,                        // number_of_remote_buffers
        DXR_NOTIMEOUT,           // remote_buffer_timeout (no timeout)
        DXR_UNPROTECTED          // protection_mode
    );
    
    std::cout << "DXR_CreateBufferPool returned: " << result << std::endl;
    
    if (result == DXR_SUCCESS) {
        std::cout << "  SUCCESS: Pool created!" << std::endl;
        std::cout << "  (Cleaning up...)" << std::endl;
        DXR_DeleteBufferPool("test_datalogger_pool");
    } else if (result == DXR_NOTRDY) {
        std::cout << "  NOTRDY: DXR daemon not running (expected)" << std::endl;
    } else {
        std::cout << "  Error: " << result << std::endl;
    }
    
    std::cout << "\n✅ DXR API is accessible and linkable!" << std::endl;
    return 0;
    
#else
    std::cout << "❌ DXR is NOT available (HAVE_DXR not defined)" << std::endl;
    std::cout << "This means DXR libraries were not found during CMake configuration." << std::endl;
    return 1;
#endif
}
