/**
 * @file DataLoggerUserTest.cpp
 * @brief Integration test for DataLogger public API
 */

#include <gtest/gtest.h>
#include "DataLogger/DataLogger.hpp"
#include "DataLogger/TextLogger.hpp"
#include "DataLogger/TraceLogger.hpp"
#include "DataLogger/DxrLogger.hpp"
#include "DataLogger/LogLevel.hpp"
#include "DataLogger/LogConfig.hpp"
#include <fstream>
#include <string>
#include <cstdint>

using namespace data_logger;

/**
 * @brief Test basic text logging functionality
 */
TEST(DataLoggerUserTest, BasicTextLogging) {
    const std::string logPath = "/tmp/test_text.log";
    
    // Remove existing log file if present
    std::remove(logPath.c_str());
    
    // Create a text logger
    auto logger = DataLogger::createTextLogger(logPath);
    ASSERT_TRUE(logger->isOpen());
    
    // Log messages at different levels
    logger->logInfo("Test info message");
    logger->logWarning("Test warning message");
    logger->logError("Test error message");
    logger->logDebug("Test debug message");
    logger->logCritical("Test critical message");
    
    // Flush and close
    logger->flush();
    logger->close();
    ASSERT_FALSE(logger->isOpen());
    
    // Verify log file exists and has content
    std::ifstream file(logPath);
    ASSERT_TRUE(file.is_open());
    
    std::string line;
    int lineCount = 0;
    while (std::getline(file, line)) {
        lineCount++;
        // Each line should contain timestamp, level, and message
        EXPECT_TRUE(line.find("[INFO]") != std::string::npos ||
                    line.find("[WARNING]") != std::string::npos ||
                    line.find("[ERROR]") != std::string::npos ||
                    line.find("[DEBUG]") != std::string::npos ||
                    line.find("[CRITICAL]") != std::string::npos);
    }
    
    EXPECT_EQ(lineCount, 5) << "Expected 5 log entries";
    
    // Cleanup
    std::remove(logPath.c_str());
}

/**
 * @brief Test log level filtering
 */
TEST(DataLoggerUserTest, LogLevelFiltering) {
    const std::string logPath = "/tmp/test_filter.log";
    
    // Remove existing log file
    std::remove(logPath.c_str());
    
    // Create logger with WARNING minimum level
    auto logger = DataLogger::createTextLogger(logPath);
    logger->setMinimumLevel(LogLevel::WARNING);
    EXPECT_EQ(logger->getMinimumLevel(), LogLevel::WARNING);
    
    // Log at different levels
    logger->logDebug("Should be filtered");
    logger->logInfo("Should also be filtered");
    logger->logWarning("Should be logged");
    logger->logError("Should be logged");
    
    logger->flush();
    logger->close();
    
    // Count lines in log file
    std::ifstream file(logPath);
    std::string line;
    int lineCount = 0;
    while (std::getline(file, line)) {
        lineCount++;
    }
    
    EXPECT_EQ(lineCount, 2) << "Only WARNING and ERROR should be logged";
    
    // Cleanup
    std::remove(logPath.c_str());
}

/**
 * @brief Test binary trace logging
 */
TEST(DataLoggerUserTest, BinaryTraceLogging) {
    const std::string logPath = "/tmp/test_trace.bin";
    
    // Remove existing log file
    std::remove(logPath.c_str());
    
    // Create a trace logger
    auto logger = DataLogger::createTraceLogger(logPath);
    ASSERT_TRUE(logger->isOpen());
    
    // Log some binary data
    struct TestData {
        std::uint32_t id;
        double value;
        std::uint8_t flags;
    } testData = {42, 3.14159, 0xFF};
    
    logger->logTrace(1001, &testData, sizeof(testData));
    
    // Log using template convenience method
    std::uint64_t timestamp = 1234567890;
    logger->logTrace(1002, timestamp);
    
    logger->flush();
    logger->close();
    
    // Verify file exists and has expected size
    std::ifstream file(logPath, std::ios::binary | std::ios::ate);
    ASSERT_TRUE(file.is_open());
    
    std::size_t fileSize = file.tellg();
    // File should have: header (32 bytes) + 2 entries
    // Entry 1: 16 bytes header + sizeof(TestData)
    // Entry 2: 16 bytes header + 8 bytes
    std::size_t expectedSize = 32 + (16 + sizeof(TestData)) + (16 + 8);
    EXPECT_EQ(fileSize, expectedSize);
    
    // Cleanup
    std::remove(logPath.c_str());
}

/**
 * @brief Test static convenience API
 */
TEST(DataLoggerUserTest, StaticConvenienceAPI) {
    // Configure default loggers
    LogConfig config;
    config.setTextLogPath("/tmp/test_static_text.log");
    config.setTraceLogPath("/tmp/test_static_trace.bin");
    DataLogger::configure(config);
    
    // Use static methods
    DataLogger::logInfo("Static info message");
    DataLogger::logError("Static error message");
    
    std::uint32_t data = 0xDEADBEEF;
    DataLogger::logTrace(2001, &data, sizeof(data));
    
    // Flush and shutdown
    DataLogger::flush();
    DataLogger::shutdown();
    
    // Verify files exist
    std::ifstream textFile("/tmp/test_static_text.log");
    EXPECT_TRUE(textFile.is_open());
    
    std::ifstream traceFile("/tmp/test_static_trace.bin");
    EXPECT_TRUE(traceFile.is_open());
    
    // Cleanup
    std::remove("/tmp/test_static_text.log");
    std::remove("/tmp/test_static_trace.bin");
}

/**
 * @brief Test DxrLogger stub
 */
TEST(DataLoggerUserTest, DxrLoggerStub) {
    LogConfig config;
    config.setDxrEnabled(true);
    config.setDxrEndpoint("http://localhost:8080/dxr");
    
    auto logger = DataLogger::createDxrLogger(config);
    
    // All methods should be callable (no-ops)
    logger->initialize();
    EXPECT_FALSE(logger->isConnected()) << "Stub should not be connected";
    
    logger->logMessage("Test message");
    
    std::uint32_t data = 42;
    logger->logMessage(3001, &data, sizeof(data));
    
    logger->shutdown();
    EXPECT_FALSE(logger->isConnected());
}

/**
 * @brief Test LogLevel string conversion
 */
TEST(DataLoggerUserTest, LogLevelConversion) {
    EXPECT_STREQ(toString(LogLevel::DEBUG), "DEBUG");
    EXPECT_STREQ(toString(LogLevel::INFO), "INFO");
    EXPECT_STREQ(toString(LogLevel::WARNING), "WARNING");
    EXPECT_STREQ(toString(LogLevel::ERROR), "ERROR");
    EXPECT_STREQ(toString(LogLevel::CRITICAL), "CRITICAL");
    
    EXPECT_EQ(fromString("DEBUG"), LogLevel::DEBUG);
    EXPECT_EQ(fromString("info"), LogLevel::INFO);
    EXPECT_EQ(fromString("WARNING"), LogLevel::WARNING);
    EXPECT_EQ(fromString("warn"), LogLevel::WARNING);
    EXPECT_EQ(fromString("ERROR"), LogLevel::ERROR);
    EXPECT_EQ(fromString("critical"), LogLevel::CRITICAL);
    
    EXPECT_THROW(fromString("INVALID"), std::invalid_argument);
}

/**
 * @brief Test LogConfig
 */
TEST(DataLoggerUserTest, LogConfig) {
    LogConfig config;
    
    // Test text logging configuration
    config.setTextLogPath("/tmp/test.log");
    EXPECT_EQ(config.getTextLogPath(), "/tmp/test.log");
    
    config.setMinimumLevel(LogLevel::WARNING);
    EXPECT_EQ(config.getMinimumLevel(), LogLevel::WARNING);
    
    config.setTextBufferSize(128 * 1024);
    EXPECT_EQ(config.getTextBufferSize(), 128 * 1024);
    
    // Test trace logging configuration
    config.setTraceLogPath("/tmp/test.bin");
    EXPECT_EQ(config.getTraceLogPath(), "/tmp/test.bin");
    
    config.setTraceBufferSize(2 * 1024 * 1024);
    EXPECT_EQ(config.getTraceBufferSize(), 2 * 1024 * 1024);
    
    // Test DXR configuration
    config.setDxrEnabled(true);
    EXPECT_TRUE(config.getDxrEnabled());
    
    config.setDxrEndpoint("http://dxr.example.com");
    EXPECT_EQ(config.getDxrEndpoint(), "http://dxr.example.com");
    
    // Test flush configuration
    config.setAutoFlushInterval(1000);
    EXPECT_EQ(config.getAutoFlushInterval(), 1000);
    
    config.setFlushOnLevel(LogLevel::ERROR);
    EXPECT_EQ(config.getFlushOnLevel(), LogLevel::ERROR);
    
    // Test synchronization configuration
    config.setThreadSafe(true);
    EXPECT_TRUE(config.getThreadSafe());
    
    config.setProcessSafe(true);
    EXPECT_TRUE(config.getProcessSafe());
    
    config.setLockFilePath("/tmp/test.lock");
    EXPECT_EQ(config.getLockFilePath(), "/tmp/test.lock");
}

/**
 * @brief Test multiple simultaneous loggers
 */
TEST(DataLoggerUserTest, MultipleLoggers) {
    const std::string textPath1 = "/tmp/test_multi_1.log";
    const std::string textPath2 = "/tmp/test_multi_2.log";
    const std::string tracePath = "/tmp/test_multi.bin";
    
    // Clean up
    std::remove(textPath1.c_str());
    std::remove(textPath2.c_str());
    std::remove(tracePath.c_str());
    
    // Create multiple loggers
    auto textLogger1 = DataLogger::createTextLogger(textPath1);
    auto textLogger2 = DataLogger::createTextLogger(textPath2);
    auto traceLogger = DataLogger::createTraceLogger(tracePath);
    
    // Log to different loggers
    textLogger1->logInfo("Message to logger 1");
    textLogger2->logInfo("Message to logger 2");
    
    std::uint32_t data = 999;
    traceLogger->logTrace(4001, data);
    
    // Close all
    textLogger1->close();
    textLogger2->close();
    traceLogger->close();
    
    // Verify all files exist
    EXPECT_TRUE(std::ifstream(textPath1).is_open());
    EXPECT_TRUE(std::ifstream(textPath2).is_open());
    EXPECT_TRUE(std::ifstream(tracePath).is_open());
    
    // Cleanup
    std::remove(textPath1.c_str());
    std::remove(textPath2.c_str());
    std::remove(tracePath.c_str());
}
